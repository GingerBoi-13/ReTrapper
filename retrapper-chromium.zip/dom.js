// ReTrapper DOM passes: shelf/nav/metadata hiding, content filters, row limits.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const { HOME, SUBS, CHAN } = RT.SEL;
  const S = () => RT.settings();
  const on = (id) => RT.on(id);
  const $$ = (sel, rootEl) => Array.from((rootEl || document).querySelectorAll(sel));

  function setHide(el, reason, flag, attr) {
    attr = attr || 'data-rt-h';
    const cur = (el.getAttribute(attr) || '').split(' ').filter(Boolean);
    const i = cur.indexOf(reason);
    if (flag && i < 0) cur.push(reason);
    else if (!flag && i >= 0) cur.splice(i, 1);
    else return;
    if (cur.length) el.setAttribute(attr, cur.join(' ')); else el.removeAttribute(attr);
  }
  RT.setHide = setHide;

  // ---- shelves by title ---------------------------------------------------------
  const SHELF_SEL = 'ytd-rich-section-renderer, ytd-shelf-renderer, ytd-horizontal-card-list-renderer, ytd-reel-shelf-renderer';
  const TITLE_RULES = [
    { flag: 'hideTrendingRow', pages: ['home'], re: /trending/i },
    { flag: 'hideTrending', pages: ['home', 'search', 'subs', 'channel'], re: /trending/i },
    { flag: 'hideForYou', pages: ['home', 'search', 'subs', 'channel'], re: /for you|recommended|you might like|picked for you/i },
    { flag: 'hidePeopleAlso', pages: ['search'], re: /people also|related searches|searches related/i },
    { flag: 'hideSearchRecs', pages: ['search'], re: /previously watched|people also watched|latest from|from related searches|for you|recommended|related to your search/i },
    { flag: 'hideSubsRecSections', pages: ['subs'], re: /recommended|suggested|you might like|for you|new to you/i },
    { flag: 'hideChannelRecs', pages: ['channel'], re: /featured channels|related channels|similar channels|other channels|recommended/i },
    { flag: 'hideLatest', pages: ['home', 'subs', 'channel'], re: /^latest\b/i }
  ];
  function shelfTitles(page) {
    const rules = TITLE_RULES.filter((r) => on(r.flag) && r.pages.includes(page));
    $$(SHELF_SEL).forEach((el) => {
      let hide = false;
      if (rules.length) {
        const t = el.querySelector('#title-text, #title, h2, yt-formatted-string.title');
        const title = ((t && t.textContent) || '').trim();
        hide = !!title && rules.some((r) => r.re.test(title));
      }
      setHide(el, 'title', hide);
    });
  }

  // ---- sidebar names ---------------------------------------------------------------
  function navNames() {
    const s = S();
    const secs = new Set(RT.lines(s.navSectionNames).map((x) => x.toLowerCase()));
    if (on('hideExplore')) secs.add('explore');
    if (on('hideMoreFromYT')) secs.add('more from youtube');
    const btns = new Set(RT.lines(s.navButtonNames).map((x) => x.toLowerCase()));
    if (on('hideHelperButtons')) ['settings', 'report history', 'help', 'send feedback'].forEach((x) => btns.add(x));
    $$('ytd-guide-section-renderer').forEach((el) => {
      const t = el.querySelector('#guide-section-title, h3, #header-entry .title');
      const title = ((t && t.textContent) || '').trim().toLowerCase();
      setHide(el, 'navsec', !!title && secs.has(title));
    });
    $$('ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer').forEach((el) => {
      const a = el.querySelector('a[title]');
      const name = ((a && a.getAttribute('title')) || (el.textContent || '')).trim().toLowerCase();
      setHide(el, 'navbtn', !!name && btns.has(name));
    });
  }

  // ---- metadata text (views, dates, subscribers) ----------------------------------------
  const META_SEL = '.inline-metadata-item, #metadata-line span, .yt-content-metadata-view-model-wiz__metadata-text, .ytContentMetadataViewModelMetadataText, ' +
    '#info-strings yt-formatted-string, ytd-watch-info-text span, #owner-sub-count, #video-count';
  const MONTH = '(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?';
  const META_RE = {
    hideViews: /^[\d.,]*\s*[KMB]?\s*(views?|watching)$|^no views$/i,
    hideTimeSince: /\bago$|^(streamed|premiered)\s.*\bago$/i,
    hidePubDate: new RegExp(`^((premiered|streamed|published|started streaming)\\s+)?(on\\s+)?(${MONTH}\\s+\\d{1,2},?\\s+\\d{4}|\\d{1,2}\\s+${MONTH}\\s+\\d{4})$`, 'i'),
    hideSubscribers: /^[\d.,]+\s*[KMB]?\s*subscribers?$/i,
    hideOtherMetrics: /^[\d.,]+\s*[KMB]?\s*(videos?|members?|watching( now)?)$/i
  };
  const isSep = (el) => el && (/^[•·|]$/.test((el.textContent || '').trim()) || /delimiter/i.test(el.className || ''));
  function metadata() {
    const flags = Object.keys(META_RE).filter((f) => on(f));
    $$(META_SEL).forEach((el) => {
      if (el.children.length > 2) return;
      const txt = (el.textContent || '').trim();
      const hit = !!txt && flags.some((f) => META_RE[f].test(txt));
      setHide(el, 'meta', hit);
      [el.previousElementSibling, el.nextElementSibling].forEach((sib) => { if (isSep(sib)) setHide(sib, 'metasep', hit); });
    });
  }

  // ---- content filters -------------------------------------------------------------------------
  const CARD_SEL = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, yt-lockup-view-model, ytd-reel-item-renderer, ytm-shorts-lockup-view-model';
  const PARENTAL = ['porn', 'xxx', 'nsfw', 'nude', 'nudes', 'sex tape', 'onlyfans', 'hentai', 'beheading', '18+', 'uncensored', 'erotic', 'fetish'];
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let C = { ver: -1 };
  function regexes(lines) {
    const out = [];
    lines.forEach((l) => {
      const m = l.match(/^\/(.+)\/([gimsuy]*)$/);
      try { out.push(m ? new RegExp(m[1], m[2].replace('g', '')) : new RegExp(esc(l), 'i')); } catch (e) { /* skip bad regex */ }
    });
    return out;
  }
  const vidId = (x) => { const m = x.match(/(?:[?&]v=|youtu\.be\/|shorts\/|^)([\w-]{11})(?:[&?/]|$)/); return m ? m[1] : x; };
  const chanKey = (x) => x.toLowerCase().replace(/^.*youtube\.com\//, '').replace(/^(channel|c|user)\//, '').replace(/^@/, '').replace(/\/$/, '');
  function compile() {
    const s = S(), L = RT.lines, lc = (a) => a.map((x) => x.toLowerCase());
    C = {
      ver: RT.version(),
      videos: new Set(L(s.blockVideos).map(vidId)),
      channels: new Set(L(s.blockChannels).map(chanKey)),
      chanIds: new Set(lc(L(s.filterChannelIds))),
      chanWords: lc(L(s.filterChannelKeywords)),
      words: lc(L(s.blockKeywords)),
      titleWords: lc(L(s.filterVideoKeywords)),
      topics: lc(L(s.blockTopics)),
      muted: lc(L(s.muteTopics)),
      re: regexes(L(s.filterRegex)),
      recWords: lc(L(s.recKeywords)).concat(lc(L(s.recTopics))),
      recChans: new Set(L(s.recBlockedChannels).map(chanKey)),
      subsWords: lc(L(s.subsKeywords)),
      chanPageWords: lc(L(s.channelKeywords)),
      parental: PARENTAL.concat(lc(L(s.parentalWords))).map((w) => new RegExp('(^|[^a-z0-9])' + esc(w.toLowerCase()) + '([^a-z0-9]|$)', 'i')),
      cAuthors: new Set(L(s.blockCommentAuthors).map(chanKey)),
      cWords: lc(L(s.commentKeywords)),
      cRe: regexes(L(s.commentRegex))
    };
  }
  const text1 = (el, sel) => { const n = el.querySelector(sel); return n ? (n.textContent || '').trim() : ''; };
  function cardInfo(card) {
    const link = card.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]');
    const href = link ? link.getAttribute('href') || '' : '';
    const chLink = card.querySelector('a[href^="/@"], a[href^="/channel/"], a[href^="/c/"], a[href^="/user/"]');
    const chHref = chLink ? chLink.getAttribute('href') || '' : '';
    let title = text1(card, '#video-title, .yt-lockup-metadata-view-model-wiz__title, .ytLockupMetadataViewModelTitle, h3');
    if (!title && link) title = link.getAttribute('title') || link.getAttribute('aria-label') || '';
    const badges = (text1(card, 'ytd-thumbnail-overlay-time-status-renderer, .badge-shape-wiz__text, .yt-badge-shape__text') || '');
    const all = (card.textContent || '').toLowerCase();
    const dur = (badges.match(/(\d+):(\d{2})(?::(\d{2}))?/) || []);
    const secs = dur.length ? (dur[3] != null ? +dur[1] * 3600 + +dur[2] * 60 + +dur[3] : +dur[1] * 60 + +dur[2]) : 0;
    return {
      href, id: (href.match(/(?:[?&]v=|shorts\/)([\w-]{11})/) || [])[1] || '',
      title: title.toLowerCase(), channel: ((chLink && chLink.textContent) || text1(card, '#channel-name, ytd-channel-name')).trim().toLowerCase(),
      chKey: chanKey(decodeURIComponent(chHref)), chId: (chHref.match(/channel\/(UC[\w-]+)/) || [])[1] || '',
      snippet: text1(card, '.metadata-snippet-text, #description-text').toLowerCase(), secs, all,
      live: !!card.querySelector('[overlay-style="LIVE"], .badge-style-type-live-now') || /\blive\b/.test(badges.toLowerCase()),
      upcoming: !!card.querySelector('[overlay-style="UPCOMING"]') || /premieres|scheduled for|upcoming/.test(all),
      members: /members only/.test(all), mix: /start_radio|[?&]list=RD/.test(href + (card.innerHTML.length < 20000 ? card.innerHTML.slice(0, 4000) : ''))
    };
  }
  const has = (list, ...hay) => list.some((w) => hay.some((h) => h && h.indexOf(w) >= 0));
  function judge(i, page) {
    const s = S();
    const ctx = page === 'watch' ? 'rec' : 'feed';
    const lists = on('filtersEnabled') && (ctx === 'rec' ? on('filterRecsOn') : on('filterFeeds'));
    let hide = false, mute = false;
    if (lists) {
      if (on('matchVideos')) {
        if (i.id && C.videos.has(i.id)) hide = true;
        if (has(C.titleWords, i.title) || has(C.words, i.title, i.channel, i.snippet)) hide = true;
        if (C.re.some((r) => r.test(i.title) || r.test(i.channel))) hide = true;
      }
      if (on('matchChannels')) {
        if (i.chKey && (C.channels.has(i.chKey) || C.channels.has(i.channel))) hide = true;
        if (i.chId && C.chanIds.has(i.chId.toLowerCase())) hide = true;
        if (has(C.chanWords, i.channel)) hide = true;
        if ((page === 'home' || page === 'watch') && i.chKey && C.recChans.has(i.chKey)) hide = true;
      }
      if (on('matchTopics') && has(C.topics, i.title, i.channel, i.snippet)) hide = true;
      if (has(C.muted, i.title, i.channel, i.snippet)) mute = true;
      if ((page === 'home' || page === 'watch') && has(C.recWords, i.title, i.channel, i.snippet)) hide = true;
      if (page === 'subs' && has(C.subsWords, i.title, i.channel)) hide = true;
      if (page === 'channel' && has(C.chanPageWords, i.title)) hide = true;
    }
    if (on('parentalFilter') && C.parental.some((r) => r.test(i.title) || r.test(i.channel))) hide = true;
    if (i.secs) {
      if (s.minDurationMin > 0 && i.secs < s.minDurationMin * 60) hide = true;
      if (s.maxDurationMin > 0 && i.secs > s.maxDurationMin * 60) hide = true;
    }
    if ((on('hideLiveStreams') && i.live) || (on('hidePremieres') && i.upcoming) || (on('hideMembersOnly') && i.members) || (on('hideMixes') && i.mix)) hide = true;
    return { hide, mute };
  }
  function cards(page) {
    if (page === 'other' || page === 'shorts' || page === 'embed') return;
    $$(CARD_SEL).forEach((card) => {
      if (card.parentElement && card.parentElement.closest(CARD_SEL)) return;
      const first = card.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]');
      const sig = RT.version() + '|' + (first ? first.getAttribute('href') : '');
      if (card.__rtSig === sig) return;
      card.__rtSig = sig;
      const r = judge(cardInfo(card), page);
      setHide(card, 'filter', r.hide);
      if (r.mute) card.setAttribute('data-rt-m', '1'); else card.removeAttribute('data-rt-m');
    });
  }

  // ---- comments ----------------------------------------------------------------------------------------
  const SPAM = /sub4sub|check out my|follow me|giveaway|whatsapp|telegram|promo|dm me|click my|my channel|subscribe to my/i;
  function comments(page) {
    if (page !== 'watch') return;
    const kinds = (S().commentFilters || []);
    $$('ytd-comment-thread-renderer').forEach((el) => {
      const body = text1(el, '#content-text');
      const sig = RT.version() + '|' + body.length;
      if (el.__rtSig === sig) return;
      el.__rtSig = sig;
      const author = text1(el, '#author-text').toLowerCase();
      const t = body.toLowerCase();
      let hide = false;
      if (on('matchComments')) {
        if (on('filtersEnabled')) {
          if (C.cAuthors.has(chanKey(author)) || C.cAuthors.has(author)) hide = true;
          if (has(C.cWords, t) || C.cRe.some((r) => r.test(body))) hide = true;
        }
        if (kinds.includes('links') && /https?:\/\/|www\./i.test(body)) hide = true;
        if (kinds.includes('spam') && SPAM.test(body)) hide = true;
        const letters = body.replace(/[^A-Za-z]/g, '');
        if (kinds.includes('caps') && letters.length > 12 && letters.replace(/[^A-Z]/g, '').length / letters.length > 0.7) hide = true;
        if (kinds.includes('emoji') && body && !/[\p{L}\p{N}]/u.test(body)) hide = true;
        if (kinds.includes('short') && body && body.length < 6) hide = true;
      }
      setHide(el, 'filter', hide);
    });
  }

  // ---- rows / columns ------------------------------------------------------------------------------------
  function limitRows(page) {
    const rows = on('homeFirstRowOnly') ? 1 : on('homeExtraRows') ? Math.max(1, S().homeMaxRows | 0) : 0;
    const items = $$(`${HOME} ytd-rich-grid-renderer ytd-rich-item-renderer`);
    if (!rows || page !== 'home') { items.forEach((i) => setHide(i, 'rows', false)); return; }
    const grid = document.querySelector(`${HOME} ytd-rich-grid-renderer`);
    const cols = (grid && parseInt(getComputedStyle(grid).getPropertyValue('--ytd-rich-grid-items-per-row'), 10)) || 4;
    let n = 0;
    items.forEach((it) => {
      const reasons = (it.getAttribute('data-rt-h') || '').split(' ').filter((r) => r && r !== 'rows');
      const other = reasons.length > 0 || it.style.display === 'none';
      if (!other) n++;
      setHide(it, 'rows', !other && n > rows * cols);
    });
  }
  function columns() {
    const s = S(), list = on('legacyListViews') ? 1 : 0;
    [[HOME, Math.max(1, Math.min(7, +s.gridColumns || 6))], [SUBS, +s.subsColumns || list], [CHAN, (on('customChannelColumns') ? Math.max(1, Math.min(7, +s.channelSearchColumns || 4)) : 0) || +s.channelColumns || list]].forEach(([scope, n]) => {
      $$(`${scope} ytd-rich-grid-renderer`).forEach((g) => {
        if (n) { g.style.setProperty('--ytd-rich-grid-items-per-row', n, 'important'); g.setAttribute('data-rt-cols', '1'); }
        else if (g.hasAttribute('data-rt-cols')) { g.style.removeProperty('--ytd-rich-grid-items-per-row'); g.removeAttribute('data-rt-cols'); }
      });
    });
  }

  // The Home "videos per row" slider also drives the Search page and channel search.
  // Items that render with no height (empty ad slots and the like) still take a grid cell and leave a
  // blank gap. Mark ones that stay empty across two checks so the grid closes up around them.
  const emptySeen = new WeakMap();
  function pruneEmpty() {
    if (!/^(home|subscriptions)$/.test((document.querySelector('ytd-browse:not([hidden])') || {}).getAttribute ? (document.querySelector('ytd-browse:not([hidden])').getAttribute('page-subtype') || '') : '')) return;
    $$('ytd-browse:not([hidden]) ytd-rich-grid-renderer > #contents > ytd-rich-item-renderer, ytd-browse:not([hidden]) ytd-rich-grid-renderer > #contents > ytd-rich-section-renderer').forEach((it) => {
      if (it.hasAttribute('data-rt-empty') || it.hasAttribute('data-rt-h')) return;
      const r = it.getBoundingClientRect();
      const cs = getComputedStyle(it);
      if (cs.display === 'none') return;
      if (r.height < 4 || cs.visibility === 'hidden') { const n = (emptySeen.get(it) || 0) + 1; emptySeen.set(it, n); if (n >= 2) it.setAttribute('data-rt-empty', '1'); }
      else emptySeen.delete(it);
    });
  }
  setInterval(() => { try { pruneEmpty(); } catch (e) { /* ignore */ } }, 1200);

  function searchGrid() {
    const s = S(), root = document.documentElement;
    const n = Math.max(1, Math.min(7, +s.gridColumns || 6));
    if (n && RT.page() === 'search' && on('searchGrid')) {
      if (root.getAttribute('data-rt-sgrid') !== String(n)) root.setAttribute('data-rt-sgrid', String(n));
      root.style.setProperty('--rt-search-cols', String(n));
    } else if (root.hasAttribute('data-rt-sgrid')) {
      root.removeAttribute('data-rt-sgrid'); root.style.removeProperty('--rt-search-cols');
    }
  }


  // ---- watched videos -----------------------------------------------------------------------------
  // How much of a card's video has been watched (0-100), read from whichever progress marker YouTube
  // uses: the classic resume-playback bar, the newer progress-bar view model, or a "Watched" badge.
  const PCT = /(-?\d+(?:\.\d+)?)\s*%/;
  function watchedPct(card) {
    let best = 0;
    const take = (n) => { if (n > best) best = n; };
    card.querySelectorAll('ytd-thumbnail-overlay-resume-playback-renderer #progress, [class*="ProgressBar"] [style*="width"], [class*="progress-bar"] [style*="width"], [class*="WatchedProgress"][style*="width"], [class*="ProgressBarSegment"][style*="width"], [class*="ResumePlaybackProgress"][style*="width"]').forEach((e) => {
      const m = (e.getAttribute('style') || '').match(/width:\s*([\d.]+)%/);
      if (m) take(+m[1]);
    });
    if (!best && card.querySelector('ytd-thumbnail-overlay-resume-playback-renderer, yt-thumbnail-overlay-progress-bar-view-model, [class*="ThumbnailOverlayProgressBar"], [class*="ResumePlayback"]')) take(1);
    if (best < 100) {
      card.querySelectorAll('ytd-thumbnail-overlay-playback-status-renderer, [class*="ThumbnailBadge"], [class*="thumbnail-badge"], badge-shape, [class*="OverlayBadge"]').forEach((e) => {
        if (/^\s*watched\s*$/i.test(e.textContent || '')) take(100);
      });
    }
    return best;
  }
  const WATCHED_SEL = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model';
  function watchedPass(page) {
    const scoped = on('hideWatched') && ['home', 'subs', 'channel', 'watch'].includes(page);
    const subsOnly = !scoped && page === 'subs' && on('subsHideWatched');
    const searchOnly = page === 'search' && on('searchHideWatched');
    if (!scoped && !subsOnly && !searchOnly) {
      $$('[data-rt-h~="watched"]').forEach((e) => setHide(e, 'watched', false));
      return;
    }
    const min = Math.max(1, Math.min(100, +S().watchedMinPct || 1));
    $$(WATCHED_SEL).forEach((c) => {
      if (c.closest('#rt-chsearch, #watch-later-shelf-section, ytd-playlist-panel-renderer, ytd-playlist-video-list-renderer')) return;
      if (page === 'watch' && !c.closest('ytd-watch-next-secondary-results-renderer, #related, #secondary')) return;
      // A lockup inside a rich item: hide the rich item so no empty slot is left behind.
      const target = c.tagName === 'YT-LOCKUP-VIEW-MODEL' ? (c.closest('ytd-rich-item-renderer, ytd-compact-video-renderer, ytd-video-renderer') || c) : c;
      if (target !== c && target.tagName === 'YTD-RICH-ITEM-RENDERER' && !c.isConnected) return;
      setHide(target, 'watched', watchedPct(target) >= min);
    });
  }

  // ---- misc -------------------------------------------------------------------------------------------------
  function misc(page) {
    if (on('removeNotifications') && /^\(\d+\)\s/.test(document.title)) document.title = document.title.replace(/^\(\d+\)\s/, '');
    // Shorts links -> normal watch links
    $$('a[href^="/shorts/"], a[data-rt-short]').forEach((a) => {
      const orig = a.getAttribute('data-rt-short');
      if (on('shortsAsVideos')) {
        const m = (orig || a.getAttribute('href')).match(/^\/shorts\/([\w-]{11})/);
        if (m) { if (!orig) a.setAttribute('data-rt-short', a.getAttribute('href')); a.setAttribute('href', '/watch?v=' + m[1]); }
      } else if (orig) { a.setAttribute('href', orig); a.removeAttribute('data-rt-short'); }
    });
    if (on('sidebarAutoCollapse') && !RT._collapsed) {
      const drawer = document.querySelector('tp-yt-app-drawer[opened]');
      const btn = document.querySelector('#guide-button button, button#guide-button');
      if (drawer && btn) { RT._collapsed = true; btn.click(); }
    }
  }

  RT.runDom = function () {
    const page = RT.page();
    if (C.ver !== RT.version()) compile();
    shelfTitles(page);
    navNames();
    metadata();
    cards(page);
    comments(page);
    limitRows(page);
    columns();
    searchGrid();
    watchedPass(page);
    misc(page);
  };
  RT.cardInfo = cardInfo;
  RT.CARD_SEL = CARD_SEL;
})();
