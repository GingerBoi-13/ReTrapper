// ReTrapper — From Your Watch Later shelf (content script)
//
// Injects a horizontal shelf of videos from the signed-in user's Watch
// Later playlist above the regular recommendation grid on the YouTube
// home page. The network fetch happens in background.js so it isn't
// subject to the page's CSP, and so host_permissions can carry the
// browser's existing youtube.com session cookies.
//
// Written for Chromium browsers (Brave, Chrome, Edge).

(function () {
  'use strict';

  const DEFAULTS = {
    showWatchLater: true,
    watchLaterTextColor: 'auto', // 'auto' | 'black' | 'white'
    layoutMode: 'scroll', // 'grid' | 'scroll'
    hideThumbnails: false,
    useDearrow: false,
    cardsPerRow: 3 // only used when thumbnails are hidden
  };

  // Card width is derived from the grid's own 3-per-row math (the actual
  // width of the area the shelf sits in, split into 3 columns with gaps),
  // not a hardcoded guess — and the exact same number is then reused for
  // the scrolling layout, so a card is the same size either way.
  const CARD_GAP = 16;

  // The grid that belongs to the HOME page. YouTube keeps other pages'
  // grids (Subscriptions, channels, ...) hidden in the document after you
  // leave them, so a plain querySelector can return a hidden one: the shelf
  // would be inserted somewhere nobody can see. Prefer the home browse page,
  // then fall back to whichever grid is actually visible.
  function findHomeGrid() {
    const home = document.querySelector('ytd-browse[page-subtype="home"] ytd-rich-grid-renderer');
    if (home) return home;
    const grids = Array.from(document.querySelectorAll('ytd-rich-grid-renderer'));
    return grids.find((g) => g.getBoundingClientRect().width > 0 && !g.closest('[hidden]')) || null;
  }

  // Measure the real native video cards so ours match exactly: card
  // width, gap between cards, and the left inset of the first column.
  function measureNative() {
    const grid = findHomeGrid();
    if (!grid) return null;
    const cards = Array.from(
      grid.querySelectorAll('ytd-rich-item-renderer ytd-rich-grid-media, ytd-rich-item-renderer #content')
    )
      .map((el) => el.getBoundingClientRect())
      .filter((r) => r.width > 150 && r.height > 30);
    if (!cards.length) return null;
    // Cards can be re-ordered or hidden, so use the leftmost card on the page (not the first in the
    // DOM and not the top row, which may hold only a card from a later column).
    const minLeft = Math.min(...cards.map((r) => r.left));
    const first = cards.find((r) => Math.abs(r.left - minLeft) < 4);
    const sameRow = cards.filter((r) => Math.abs(r.top - first.top) < 4).sort((a, b) => a.left - b.left);
    const second = sameRow.find((r) => r.left > first.right - 2);
    const gridRect = grid.getBoundingClientRect();
    return {
      width: Math.round(first.width),
      gap: second ? Math.max(0, Math.min(48, Math.round(second.left - first.right))) : CARD_GAP,
      inset: Math.max(0, Math.min(120, Math.round(first.left - gridRect.left)))
    };
  }

  let settings = { ...DEFAULTS };
  let observer = null;

  const SHELF_ID = 'watch-later-shelf-section';
  let requestInFlight = false;
  let lastAttempt = 0;
  let lastResult = null;
  let lastResultAt = 0;
  const COOLDOWN_MS = 5000;

  function isHomePage() {
    return location.hostname === 'www.youtube.com' && location.pathname === '/';
  }

  // --- style sampling (match the page's own look) ---------------------------

  function samplePageStyles() {
    const candidates = [document.querySelector('ytd-app'), document.body, document.documentElement].filter(
      Boolean
    );

    let color = null;
    let fontFamily = null;
    candidates.forEach((el) => {
      const style = window.getComputedStyle(el);
      if (!color && style.color && style.color !== 'rgba(0, 0, 0, 0)') color = style.color;
      if (!fontFamily && style.fontFamily) fontFamily = style.fontFamily;
    });

    const homeGrid = findHomeGrid();
    const thumbEl = homeGrid && homeGrid.querySelector('ytd-rich-item-renderer ytd-thumbnail, ytd-rich-item-renderer #thumbnail');
    const thumbStyle = thumbEl ? window.getComputedStyle(thumbEl) : null;

    return {
      color,
      fontFamily,
      borderRadius: thumbStyle ? thumbStyle.borderRadius : null
    };
  }

  function resolveStyles() {
    const sampled = samplePageStyles();

    let primary;
    if (settings.watchLaterTextColor === 'black') {
      primary = '#0f0f0f';
    } else if (settings.watchLaterTextColor === 'white') {
      primary = '#f1f1f1';
    } else {
      // Auto: keep the page's own text colour when it reads clearly against
      // the page background; otherwise pick by the detected theme.
      const det = window.RT && RT.detectTheme ? RT.detectTheme() : null;
      const dark = det ? det.theme === 'dark' : true;
      const themed = dark ? '#f1f1f1' : '#0f0f0f';
      const pc = sampled.color && RT.parseColor ? RT.parseColor(sampled.color) : null;
      if (pc && det && det.bg) primary = Math.abs(RT.lum(pc) - RT.lum(det.bg)) >= 90 ? sampled.color : themed;
      else primary = det ? themed : sampled.color || '#f1f1f1';
    }

    return {
      primary,
      fontFamily: sampled.fontFamily || 'Roboto, Arial, sans-serif',
      borderRadius: sampled.borderRadius || '12px'
    };
  }

  function areHomeThumbnailsHidden() {
    const homeGrid = findHomeGrid();
    const nativeImg = homeGrid && homeGrid.querySelector('ytd-thumbnail img, yt-image img');
    if (!nativeImg) return false;
    const style = window.getComputedStyle(nativeImg);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) {
      return true;
    }
    const rect = nativeImg.getBoundingClientRect();
    return rect.width === 0 && rect.height === 0;
  }

  // --- fetch via background script -------------------------------------------

  async function requestWatchLaterVideos() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'WATCH_LATER_SHELF_FETCH' });
      if (response && response.videos) loadAvatars(response.videos);
      try { document.documentElement.dataset.rtWl = 'videos:' + ((response && response.videos && response.videos.length) || 0) + ' error:' + ((response && response.error) || 'none') + ' signedIn:' + (response && response.signedIn) + ' at:' + new Date().toISOString().slice(11, 19); } catch (e) { /* ignore */ }
      return response || { videos: [], signedIn: true, error: 'no-response' };
    } catch (e) {
      return { videos: [], signedIn: true, error: String(e) };
    }
  }

  // --- optional DeArrow titles & thumbnails -------------------------------------

  let branding = {}; // videoId -> { title?, thumbnail? }

  async function fetchBranding(videos) {
    if (!settings.useDearrow || !videos || !videos.length) return;
    const needed = videos.map((v) => v.videoId).filter((id) => id && !(id in branding));
    if (!needed.length) return;
    try {
      const got = await chrome.runtime.sendMessage({ type: 'WATCH_LATER_SHELF_DEARROW', videoIds: needed });
      needed.forEach((id) => {
        branding[id] = (got && got[id]) || {}; // remember misses too
      });
    } catch (e) {
      /* DeArrow unavailable: the shelf just shows the originals */
    }
  }

  function applyBranding(video) {
    if (!settings.useDearrow) return video;
    const b = branding[video.videoId];
    if (!b) return video;
    return { ...video, title: b.title || video.title, thumbnail: b.thumbnail || video.thumbnail };
  }

  async function refreshBrandingAndRerender() {
    if (settings.useDearrow && lastResult) await fetchBranding(lastResult.videos);
    rerenderIfPresent();
  }

  // --- playlist edits (menu, undo, remove all) -----------------------------------

  let editCounter = 0;

  // Sends playlist edit actions to page-bridge.js (which runs in the page
  // itself and uses YouTube's own signed-in session) and waits for the result.
  function editPlaylist(actions) {
    return new Promise((resolve) => {
      const requestId = `wls-${Date.now()}-${++editCounter}`;
      const timer = setTimeout(() => {
        window.removeEventListener('watch-later-shelf-edit-result', onResult);
        resolve({ ok: false, error: 'timeout' });
      }, 15000);
      function onResult(e) {
        let data;
        try {
          data = JSON.parse(e.detail);
        } catch (err) {
          return;
        }
        if (data.requestId !== requestId) return;
        clearTimeout(timer);
        window.removeEventListener('watch-later-shelf-edit-result', onResult);
        resolve(data);
      }
      window.addEventListener('watch-later-shelf-edit-result', onResult);
      window.dispatchEvent(
        new CustomEvent('watch-later-shelf-edit', { detail: JSON.stringify({ requestId, actions }) })
      );
    });
  }

  async function requestAllWatchLaterVideos() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'WATCH_LATER_SHELF_FETCH_ALL' });
      return response || { videos: [], error: 'no-response' };
    } catch (e) {
      return { videos: [], error: String(e) };
    }
  }

  function isLightColor(color) {
    const nums = String(color).match(/[\d.]+/g);
    if (!nums || nums.length < 3) return true;
    const [r, g, b] = nums.map(Number);
    return 0.299 * r + 0.587 * g + 0.114 * b > 150;
  }

  // Is the page (or the user's chosen theme) dark? The sun/moon override wins;
  // otherwise look at what the page actually paints, then YouTube's own
  // dark-mode flag. Used so popups match the theme instead of a fixed color.
  function isDarkPage() {
    if (settings.watchLaterTextColor === 'black') return false;
    if (settings.watchLaterTextColor === 'white') return true;
    if (window.RT && RT.detectTheme) return RT.detectTheme().theme === 'dark';
    return document.documentElement.hasAttribute('dark');
  }

  // --- toast (like YouTube's bottom-left snackbar) ---------------------------------

  let toastEl = null;
  let toastTimer = null;

  function showToast(message, actionLabel, onAction) {
    if (toastEl) toastEl.remove();
    clearTimeout(toastTimer);
    toastEl = document.createElement('div');
    toastEl.setAttribute('role', 'status');
    toastEl.style.cssText =
      'position:fixed;left:24px;bottom:24px;z-index:2400;display:flex;align-items:center;gap:16px;max-width:calc(100vw - 48px);' +
      'padding:12px 16px;border-radius:8px;background:#323232;color:#fff;font:400 14px/20px Roboto,Arial,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.4);';
    const text = document.createElement('span');
    text.textContent = message;
    toastEl.appendChild(text);
    if (actionLabel && onAction) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = actionLabel;
      btn.style.cssText =
        'border:none;background:transparent;color:#3ea6ff;font:500 14px/20px Roboto,Arial,sans-serif;text-transform:uppercase;cursor:pointer;padding:0;';
      btn.addEventListener('click', () => {
        toastEl.remove();
        onAction();
      });
      toastEl.appendChild(btn);
    }
    document.body.appendChild(toastEl);
    toastTimer = setTimeout(() => {
      if (toastEl) toastEl.remove();
      toastEl = null;
    }, 7000);
  }

  // --- per-video menu ------------------------------------------------------------------

  let openMenu = null;

  function closeMenu() {
    if (!openMenu) return;
    openMenu.el.remove();
    openMenu.btn.setAttribute('aria-expanded', 'false');
    document.removeEventListener('mousedown', openMenu.onOutside, true);
    document.removeEventListener('keydown', openMenu.onKey, true);
    window.removeEventListener('scroll', closeMenu, true);
    window.removeEventListener('resize', closeMenu);
    openMenu = null;
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); } catch (err) { /* ignore */ }
      ta.remove();
    }
  }

  async function removeVideo(video, card) {
    card.remove(); // feels instant; restored by a refresh if the edit fails
    const res = await editPlaylist([{ action: 'ACTION_REMOVE_VIDEO_BY_VIDEO_ID', removedVideoId: video.videoId }]);
    if (!res.ok) {
      showToast("Couldn't remove that video from Watch later.");
      refreshShelf();
      return;
    }
    if (lastResult && lastResult.videos) {
      lastResult = { ...lastResult, videos: lastResult.videos.filter((v) => v.videoId !== video.videoId) };
    }
    showToast('Removed from Watch later', 'Undo', async () => {
      const undo = await editPlaylist([{ action: 'ACTION_ADD_VIDEO', addedVideoId: video.videoId }]);
      if (!undo.ok) showToast("Couldn't undo that.");
      refreshShelf();
    });
  }

  function openVideoMenu(btn, video, card, styles) {
    if (openMenu && openMenu.btn === btn) {
      closeMenu();
      return;
    }
    closeMenu();

    const light = isDarkPage(); // dark theme => dark menu
    const bg = light ? '#282828' : '#ffffff';
    const fg = light ? '#f1f1f1' : '#0f0f0f';
    const hover = light ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.08)';

    const ICONS = {
      remove: 'M11 17H9V8h2v9zm4-9h-2v9h2V8zm4-4v1h-1v16H6V5H5V4h4V3h6v1h4zm-2 1H7v15h10V5z',
      link: 'M17 7h-4v2h4c1.65 0 3 1.35 3 3s-1.35 3-3 3h-4v2h4c2.76 0 5-2.24 5-5s-2.24-5-5-5zm-6 8H7c-1.65 0-3-1.35-3-3s1.35-3 3-3h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-2zm-3-4h8v2H8v-2z'
    };
    const items = [
      { label: 'Remove from Watch later', icon: ICONS.remove, run: () => removeVideo(video, card) },
      { label: 'Copy link', icon: ICONS.link, run: () => copyText(`https://www.youtube.com/watch?v=${video.videoId}`) }
    ];

    const menu = document.createElement('div');
    menu.setAttribute('role', 'menu');
    menu.style.cssText =
      `position:fixed;z-index:2300;min-width:236px;padding:8px 0;border-radius:12px;background:${bg};color:${fg};` +
      'box-shadow:0 4px 32px rgba(0,0,0,.4);font:400 14px/20px Roboto,Arial,sans-serif;';

    items.forEach((item) => {
      const row = document.createElement('div');
      row.setAttribute('role', 'menuitem');
      row.tabIndex = 0;
      row.style.cssText = 'display:flex;align-items:center;gap:16px;padding:8px 16px;cursor:pointer;white-space:nowrap;';
      const ns = 'http://www.w3.org/2000/svg';
      const icon = document.createElementNS(ns, 'svg');
      icon.setAttribute('viewBox', '0 0 24 24');
      icon.setAttribute('width', '24');
      icon.setAttribute('height', '24');
      icon.setAttribute('fill', 'currentColor');
      icon.style.flex = '0 0 auto';
      const path = document.createElementNS(ns, 'path');
      path.setAttribute('d', item.icon);
      icon.appendChild(path);
      const label = document.createElement('span');
      label.textContent = item.label;
      row.appendChild(icon);
      row.appendChild(label);
      row.addEventListener('mouseenter', () => { row.style.background = hover; });
      row.addEventListener('mouseleave', () => { row.style.background = 'transparent'; });
      const activate = () => {
        closeMenu();
        item.run();
      };
      row.addEventListener('click', activate);
      row.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          activate();
        }
      });
      menu.appendChild(row);
    });

    document.body.appendChild(menu);
    const r = btn.getBoundingClientRect();
    const mr = menu.getBoundingClientRect();
    let left = Math.min(Math.max(8, r.right - mr.width), window.innerWidth - mr.width - 8);
    let top = r.bottom + 4;
    if (top + mr.height > window.innerHeight - 8) top = Math.max(8, r.top - mr.height - 4);
    menu.style.left = `${left}px`;
    menu.style.top = `${top}px`;

    btn.setAttribute('aria-expanded', 'true');
    const onOutside = (e) => {
      if (!menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) closeMenu();
    };
    const onKey = (e) => {
      if (e.key === 'Escape') closeMenu();
    };
    document.addEventListener('mousedown', onOutside, true);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('scroll', closeMenu, true);
    window.addEventListener('resize', closeMenu);
    openMenu = { el: menu, btn, onOutside, onKey };
  }

  function buildMenuButton(video, card, styles) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'wls-menu-btn';
    btn.setAttribute('aria-label', 'Action menu');
    btn.setAttribute('aria-haspopup', 'menu');
    btn.setAttribute('aria-expanded', 'false');
    btn.style.cssText =
      `flex:0 0 auto;width:32px;height:32px;margin:-4px -6px 0 0;padding:0;border:none;border-radius:50%;background:transparent;color:${styles.primary};` +
      'cursor:pointer;display:flex;align-items:center;justify-content:center;';
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('fill', 'currentColor');
    [5, 12, 19].forEach((cy) => {
      const dot = document.createElementNS(ns, 'circle');
      dot.setAttribute('cx', '12');
      dot.setAttribute('cy', String(cy));
      dot.setAttribute('r', '2');
      svg.appendChild(dot);
    });
    btn.appendChild(svg);
    btn.addEventListener('mouseenter', () => { btn.style.background = 'rgba(128,128,128,.25)'; });
    btn.addEventListener('mouseleave', () => { btn.style.background = 'transparent'; });
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openVideoMenu(btn, video, card, styles);
    });
    return btn;
  }

  // --- "Remove all" in the shelf's title row ------------------------------------------

  async function removeAllVideos(button) {
    if (!window.confirm("Remove ALL videos from your Watch Later playlist?\n\nThis can't be undone.")) return;

    const original = button.textContent;
    button.disabled = true;
    button.style.opacity = '0.6';
    let removed = 0;
    let previous = '';
    let stuck = 0;
    let failed = false;

    for (let round = 0; round < 60; round++) {
      const all = await requestAllWatchLaterVideos();
      if (all.error && !(all.videos || []).length) {
        failed = true;
        break;
      }
      const ids = (all.videos || []).map((v) => v.videoId).filter(Boolean);
      if (!ids.length) break;

      const key = ids.join(',');
      if (key === previous) {
        // Same list again: the last batch hasn't shown up as removed yet.
        if (++stuck >= 3) {
          failed = true;
          break;
        }
        await new Promise((r) => setTimeout(r, 1500));
        continue;
      }
      stuck = 0;
      previous = key;

      const res = await editPlaylist(ids.map((id) => ({ action: 'ACTION_REMOVE_VIDEO_BY_VIDEO_ID', removedVideoId: id })));
      if (!res.ok) {
        failed = true;
        break;
      }
      removed += ids.length;
      button.textContent = `Removing… ${removed}`;
      await new Promise((r) => setTimeout(r, 500));
    }

    lastResult = { videos: [], signedIn: true, error: null };
    lastResultAt = Date.now();
    const section = document.getElementById(SHELF_ID);
    if (section) {
      rerenderIfPresent();
    } else {
      button.disabled = false;
      button.style.opacity = '1';
      button.textContent = original;
    }
    if (failed) {
      showToast(`Removed ${removed} video${removed === 1 ? '' : 's'}, then something went wrong. Check your Watch Later list.`);
      refreshShelf();
    } else {
      showToast(`Removed ${removed} video${removed === 1 ? '' : 's'} from Watch later`);
    }
  }

  function buildRemoveAllButton(styles) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Remove all videos';
    btn.style.cssText =
      `flex:0 0 auto;height:32px;padding:0 14px;border:none;border-radius:16px;cursor:pointer;color:${styles.primary};` +
      `background:color-mix(in srgb, ${styles.primary} 12%, transparent);font:500 13px/32px Roboto,Arial,sans-serif;white-space:nowrap;`;
    btn.addEventListener('click', () => removeAllVideos(btn));
    return btn;
  }

  // --- building the shelf ------------------------------------------------------

  // Navigate the way YouTube's own thumbnails do: an in-page (SPA)
  // navigation instead of a full page load. A full reload loses the
  // click's user-activation, so the browser blocks autoplay; an in-page
  // navigation keeps playback starting on its own, like a native click.
  function navigateLikeYouTube(video, href) {
    try {
      const app = document.querySelector('ytd-app');
      if (!app) throw new Error('no ytd-app');
      const index = (video.index ?? 0) + 1;
      const detail = {
        endpoint: {
          commandMetadata: {
            webCommandMetadata: {
              url: `/watch?v=${video.videoId}&list=WL&index=${index}`,
              webPageType: 'WEB_PAGE_TYPE_WATCH',
              rootVe: 3832
            }
          },
          watchEndpoint: { videoId: video.videoId, playlistId: 'WL', index: index - 1 }
        }
      };
      window.dispatchEvent(new CustomEvent('watch-later-shelf-navigate', { detail: JSON.stringify(detail) }));
      // Safety net: if YouTube didn't pick it up, do a normal navigation.
      setTimeout(() => {
        if (isHomePage()) location.assign(href);
      }, 1500);
    } catch (e) {
      location.assign(href);
    }
  }


  // --- channel avatars and dates on shelf cards ---------------------------------------------
  const EXT = typeof browser !== 'undefined' ? browser : chrome;
  let avatars = {}; // channelUrl -> picture url
  const avatarAsked = new Set();
  async function loadAvatars(videos) {
    const urls = Array.from(new Set((videos || []).map((v) => v.channelUrl).filter((u) => u && !(u in avatars) && !avatarAsked.has(u))));
    if (!urls.length) return;
    urls.forEach((u) => avatarAsked.add(u));
    try {
      const got = await EXT.runtime.sendMessage({ type: 'WATCH_LATER_SHELF_AVATARS', urls });
      if (got && Object.keys(got).length) { Object.assign(avatars, got); rerenderIfPresent(); }
    } catch (e) { /* the shelf just shows initials */ }
  }
  function dateTextFor(video) {
    try { if (window.RT && typeof RT.dateOf === 'function') { const d = RT.dateOf(video.videoId); if (d) return d; } } catch (e) { /* ignore */ }
    return video.published || '';
  }
  function updateShelfDates() {
    document.querySelectorAll('#' + SHELF_ID + ' [data-wls-date]').forEach((el) => {
      const id = el.getAttribute('data-wls-date');
      const t = (window.RT && typeof RT.dateOf === 'function' && RT.dateOf(id)) || el.getAttribute('data-wls-fallback') || '';
      if (t && el.textContent !== t) el.textContent = t;
    });
  }
  window.addEventListener('rt-dates-changed', () => { try { updateShelfDates(); } catch (e) { /* ignore */ } });

  function buildCard(video, hideThumbnail, styles, cardWidth) {
    // The card is a plain container. Thumbnail link, title link, channel link
    // and the 3-dot menu are siblings, so each goes to its own destination
    // (links can't be nested inside links).
    const card = document.createElement('div');
    card.className = 'wls-card';
    card.style.cssText = `display: block; flex: 0 0 ${cardWidth}; width: ${cardWidth}; color: inherit; font-family: ${styles.fontFamily};`;

    // Opens the video inside the Watch Later playlist (list=WL), at its
    // position, so next/previous and autoplay follow the playlist.
    const videoHref = `https://www.youtube.com/watch?v=${video.videoId}&list=WL&index=${(video.index ?? 0) + 1}`;
    const attachNavigation = (a) => {
      a.href = videoHref;
      a.addEventListener('click', (e) => {
        if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
        e.preventDefault();
        markAutoplay();
        navigateLikeYouTube(video, videoHref);
      });
    };

    if (!hideThumbnail) {
      const thumbLink = document.createElement('a');
      thumbLink.style.cssText = 'display: block; text-decoration: none; color: inherit;';
      attachNavigation(thumbLink);

      const thumbWrap = document.createElement('div');
      thumbWrap.style.cssText = `position: relative; width: 100%; aspect-ratio: 16 / 9; border-radius: ${styles.borderRadius}; overflow: hidden; background: #000;`;

      if (video.thumbnail) {
        const img = document.createElement('img');
        img.src = video.thumbnail;
        img.loading = 'lazy';
        img.alt = video.title;
        img.style.cssText = 'width: 100%; height: 100%; object-fit: cover; display: block;';
        thumbWrap.appendChild(img);
      }

      if (video.duration) {
        const dur = document.createElement('span');
        dur.textContent = video.duration;
        dur.style.cssText = `position: absolute; bottom: 4px; right: 4px; background: rgba(0,0,0,0.8); color: #fff; font-size: 11px; line-height: 1; padding: 3px 4px; border-radius: 4px; font-family: ${styles.fontFamily};`;
        thumbWrap.appendChild(dur);
      }

      thumbLink.appendChild(thumbWrap);
      card.appendChild(thumbLink);
    }

    const info = document.createElement('div');
    info.style.cssText = `display: flex; align-items: flex-start; gap: 4px; margin-top: ${hideThumbnail ? '0' : '12px'};`;

    const textCol = document.createElement('div');
    textCol.style.cssText = 'flex: 1 1 auto; min-width: 0;';

    const titleLink = document.createElement('a');
    titleLink.textContent = video.title;
    titleLink.title = video.title;
    attachNavigation(titleLink);
    titleLink.style.cssText = `font-size: 16px; line-height: 22px; font-weight: 500; text-decoration: none; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;`;
    titleLink.style.setProperty('color', styles.primary, 'important');
    textCol.appendChild(titleLink);

    const meta = document.createElement('div');
    meta.style.cssText = 'display: flex; flex-wrap: wrap; align-items: baseline; column-gap: 8px; margin-top: 4px;';
    if (video.channel) {
      const channel = document.createElement(video.channelUrl ? 'a' : 'div');
      channel.textContent = video.channel;
      channel.style.cssText = `display: ${video.channelUrl ? 'inline-block' : 'block'}; max-width: 100%; font-size: 14px; line-height: 20px; color: ${styles.primary}; opacity: 0.7; text-decoration: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; vertical-align: top;`;
      if (video.channelUrl) {
        channel.href = video.channelUrl;
        channel.title = video.channel;
        channel.addEventListener('mouseenter', () => {
          channel.style.opacity = '1';
          channel.style.textDecoration = 'underline';
        });
        channel.addEventListener('mouseleave', () => {
          channel.style.opacity = '0.7';
          channel.style.textDecoration = 'none';
        });
      }
      meta.appendChild(channel);
    }
    const dateStr = dateTextFor(video);
    if (dateStr) {
      const dateEl = document.createElement('span');
      dateEl.textContent = dateStr;
      dateEl.setAttribute('data-wls-date', video.videoId);
      dateEl.setAttribute('data-wls-fallback', video.published || '');
      dateEl.style.cssText = `font-size: 14px; line-height: 20px; color: ${styles.primary}; opacity: 0.7; white-space: nowrap;`;
      meta.appendChild(dateEl);
    }
    if (meta.childNodes.length) textCol.appendChild(meta);

    {
      const pic = document.createElement(video.channelUrl ? 'a' : 'div');
      if (video.channelUrl) pic.href = video.channelUrl;
      pic.style.cssText = 'flex: 0 0 36px; width: 36px; height: 36px; margin-right: 8px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; text-decoration: none; background: rgba(127,127,127,0.35); font-size: 15px; font-weight: 500;';
      pic.style.setProperty('color', styles.primary, 'important');
      const src = video.channelUrl && avatars[video.channelUrl];
      if (src) {
        const im = document.createElement('img');
        im.src = src; im.alt = ''; im.loading = 'lazy';
        im.style.cssText = 'width: 100%; height: 100%; object-fit: cover; display: block;';
        pic.appendChild(im);
      } else {
        pic.textContent = (video.channel || '?').trim().charAt(0).toUpperCase();
      }
      info.appendChild(pic);
    }
    info.appendChild(textCol);
    info.appendChild(buildMenuButton(video, card, styles));
    card.appendChild(info);
    return card;
  }


  // The home page keeps a fixed/sticky bar (filter chips) near the top. If it overlaps the shelf's
  // heading, push the shelf down just enough to clear it.
  let topExtra = 0;
  function clearStickyTop() {
    const sec = document.getElementById(SHELF_ID);
    if (!sec || window.scrollY > 5) return;
    const h = sec.querySelector('[role="heading"]');
    if (!h) return;
    const hr = h.getBoundingClientRect();
    if (!hr.height) return;
    let need = 0;
    const chips = document.querySelector('ytd-browse:not([hidden]) #chips-wrapper, ytd-browse:not([hidden]) ytd-feed-filter-chip-bar-renderer');
    if (chips) {
      const pos = getComputedStyle(chips).position;
      const cr = chips.getBoundingClientRect();
      if ((pos === 'fixed' || pos === 'sticky') && cr.height && cr.bottom + 8 > hr.top && cr.top < hr.bottom) need = Math.max(need, cr.bottom + 12 - hr.top);
    }
    const x = Math.min(innerWidth - 2, hr.left + 20), y = hr.top + hr.height / 2;
    const top = document.elementFromPoint(x, y);
    if (top && !sec.contains(top) && !top.contains(sec)) {
      const tr = top.getBoundingClientRect();
      if (tr.bottom - hr.top > 0 && tr.bottom - hr.top < 140) need = Math.max(need, tr.bottom + 12 - hr.top);
    }
    if (need > 2) {
      topExtra = Math.min(140, topExtra + Math.ceil(need));
      sec.style.marginTop = (24 + topExtra) + 'px';
    }
  }
  setInterval(() => { try { clearStickyTop(); } catch (e) { /* ignore */ } }, 700);

  function buildSection(result) {
    const section = document.createElement('div');
    section.id = SHELF_ID;
    const native = measureNative();
    const inset = native ? native.inset : 24;
    section.dataset.nativeMeasured = native ? '1' : '0';
    section.style.cssText = `margin: ${24 + topExtra}px 0 24px; padding: 0 ${inset}px; background: transparent; box-sizing: border-box; width: 100%; max-width: 100%; min-width: 0; align-self: stretch; overflow: hidden;`;

    const isEmpty = !result.error && result.signedIn !== false && !result.videos.length;
    const styles = resolveStyles();

    const heading = document.createElement('div');
    heading.setAttribute('role', 'heading');
    heading.setAttribute('aria-level', '2');
    heading.style.cssText = `position: relative; z-index: 3; display: block; visibility: visible; opacity: 1; font-size: 20px; line-height: 28px; font-weight: 500; margin: 0; font-family: ${styles.fontFamily};`;

    const headingLink = document.createElement('a');
    headingLink.href = 'https://www.youtube.com/playlist?list=WL';
    headingLink.textContent = isEmpty ? 'You are all caught up on Watch Later' : 'From Your Watch Later';
    headingLink.style.setProperty('color', styles.primary, 'important');
    headingLink.style.setProperty('-webkit-text-fill-color', styles.primary, 'important');
    headingLink.style.setProperty('text-decoration', 'none', 'important');
    headingLink.style.setProperty('display', 'inline-block', 'important');
    headingLink.addEventListener('mouseenter', () => {
      headingLink.style.setProperty('text-decoration', 'underline', 'important');
    });
    headingLink.addEventListener('mouseleave', () => {
      headingLink.style.setProperty('text-decoration', 'none', 'important');
    });

    heading.appendChild(headingLink);

    // Hover-reveal for the 3-dot menu buttons (like YouTube's own cards).
    const hoverCss = document.createElement('style');
    hoverCss.textContent =
      '.wls-card .wls-menu-btn{opacity:0;transition:opacity .15s ease}' +
      '.wls-card:hover .wls-menu-btn,.wls-card .wls-menu-btn:focus-visible,.wls-card .wls-menu-btn[aria-expanded="true"]{opacity:1}';
    section.appendChild(hoverCss);

    // Title on the left, "Remove all videos" on the right, same row.
    const headRow = document.createElement('div');
    headRow.style.cssText = 'position: relative; z-index: 3; display: flex; align-items: center; justify-content: space-between; gap: 16px; margin: 0 0 16px;';
    headRow.appendChild(heading);
    const hasVideos = !result.error && result.signedIn !== false && result.videos && result.videos.length;
    if (hasVideos) headRow.appendChild(buildRemoveAllButton(styles));
    section.appendChild(headRow);

    let message = null;
    if (result.error) {
      message = "Couldn't load your Watch Later videos right now.";
    } else if (result.signedIn === false) {
      message = 'Sign in to YouTube to see your Watch Later videos here.';
    } else if (isEmpty) {
      message = 'Nothing saved for later right now.';
    }

    if (message) {
      const empty = document.createElement('p');
      empty.textContent = message;
      empty.style.cssText = `color: ${styles.primary}; opacity: 0.7; font-size: 13px; font-family: ${styles.fontFamily}; margin: 0;`;
      section.appendChild(empty);
      return section;
    }

    const hideAllThumbs = !!(window.RT && window.RT.state && window.RT.state.tokens.has('thumbsHideAll'));
    const textOnly = settings.hideThumbnails || hideAllThumbs;
    const hideThumbnail = textOnly || areHomeThumbnailsHidden();
    const layoutMode = settings.layoutMode === 'grid' ? 'grid' : 'scroll';
    const gap = native ? native.gap : CARD_GAP;
    let cardWidth = `${native ? native.width : 533}px`;
    if (textOnly && native) {
      // Same width and gap as the real grid columns, so shelf cards line up with the videos below.
      cardWidth = `${native.width}px`;
    } else if (textOnly) {
      // Text-only cards: size each card as an exact fraction of the row's
      // real width (CSS calc against the container), so exactly N whole
      // cards always fit, whatever the window size.
      const perRow = Math.max(1, Math.min(8, parseInt(settings.cardsPerRow, 10) || 3));
      cardWidth = `calc((100% - ${gap * (perRow - 1)}px) / ${perRow})`;
    }
    const grid = document.createElement('div');
    grid.style.cssText =
      layoutMode === 'scroll'
        ? `display: flex; width: 100%; max-width: 100%; min-width: 0; gap: ${gap}px; overflow-x: auto; padding-bottom: 10px; scrollbar-width: auto;`
        : `display: flex; flex-wrap: wrap; gap: 24px ${gap}px;`;
    result.videos.forEach((video) => grid.appendChild(buildCard(applyBranding(video), hideThumbnail, styles, cardWidth)));
    if (layoutMode === 'scroll') {
      grid.style.overscrollBehaviorX = 'contain';
      // Mouse wheel over the row scrolls it sideways. Listening in the
      // capture phase on the whole shelf means nothing else on the page can
      // swallow the wheel first. At either end the wheel falls through so
      // the page itself keeps scrolling normally.
      section.addEventListener(
        'wheel',
        (e) => {
          if (!grid.contains(e.target)) return;
          if (e.ctrlKey) return; // pinch-zoom
          const horizontal = Math.abs(e.deltaX) > Math.abs(e.deltaY);
          const delta = horizontal ? e.deltaX : e.deltaY;
          const max = grid.scrollWidth - grid.clientWidth;
          if (max <= 0 || !delta) return;
          const unit = e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? grid.clientWidth : 1;
          const atStart = grid.scrollLeft <= 0 && delta < 0;
          const atEnd = grid.scrollLeft >= max - 1 && delta > 0;
          if (atStart || atEnd) return;
          e.preventDefault();
          e.stopPropagation();
          grid.scrollLeft = Math.max(0, Math.min(max, grid.scrollLeft + delta * unit));
        },
        { passive: false, capture: true }
      );
    }

    section.appendChild(grid);

    return section;
  }

  function removeShelf() {
    const existing = document.getElementById(SHELF_ID);
    if (existing) existing.remove();
  }

  // Returns { parent, before } describing where the shelf goes, or null.
  // The filter chip bar (All / Gaming / Music / ...) lives INSIDE
  // ytd-rich-grid-renderer, so inserting before the grid would put the
  // shelf above the chips. Instead we find the chip bar's top-level
  // wrapper inside the grid renderer and insert right after it, so the
  // order is chips -> shelf -> videos.
  function findInsertionPoint() {
    const grid = findHomeGrid();
    if (!grid) return null;

    const chips = grid.querySelector('ytd-feed-filter-chip-bar-renderer');
    if (chips) {
      let wrapper = chips;
      while (wrapper.parentElement && wrapper.parentElement !== grid) {
        wrapper = wrapper.parentElement;
      }
      if (wrapper.parentElement === grid) {
        return { parent: grid, before: wrapper.nextSibling };
      }
    }

    // No chip bar: go directly above the grid.
    if (grid.parentElement) return { parent: grid.parentElement, before: grid };
    return null;
  }

  async function ensureShelf() {
    if (!settings.showWatchLater) {
      removeShelf();
      return;
    }
    const existing = document.getElementById(SHELF_ID);
    if (existing) {
      // Already in the right page? Then nothing to do. If it ended up inside
      // another (hidden) page's grid, drop it and rebuild in the home grid.
      const homeGrid = findHomeGrid();
      if (!homeGrid || existing.closest('ytd-browse') === homeGrid.closest('ytd-browse')) return;
      existing.remove();
    }
    if (requestInFlight) return;
    if (Date.now() - lastAttempt < COOLDOWN_MS) return;

    const point = findInsertionPoint();
    if (!point) return;

    lastAttempt = Date.now();

    const placeholder = document.createElement('div');
    placeholder.id = SHELF_ID;
    placeholder.style.cssText = 'margin: 24px 0;';
    point.parent.insertBefore(placeholder, point.before);

    // If YouTube re-renders and drops the shelf, reuse the recent result
    // instead of hitting the network again.
    if (lastResult && Date.now() - lastResultAt < 60000) {
      placeholder.replaceWith(buildSection(lastResult));
      return;
    }

    requestInFlight = true;

    const result = await requestWatchLaterVideos();
    requestInFlight = false;
    lastResult = result;
    lastResultAt = Date.now();
    if (Date.now() - lastChangeAt < 40000) startLadder(signature(result));

    if (settings.useDearrow && result.videos && result.videos.length) {
      // Wait briefly so DeArrow titles are there from the first paint;
      // if the service is slow, show originals and swap in when it answers.
      const pending = fetchBranding(result.videos);
      const timedOut = await Promise.race([pending.then(() => false), new Promise((r) => setTimeout(() => r(true), 2500))]);
      if (timedOut) pending.then(rerenderIfPresent);
    }

    const current = document.getElementById(SHELF_ID);
    if (!current || !settings.showWatchLater || !isHomePage()) {
      if (current) current.remove();
      return;
    }
    current.replaceWith(buildSection(result));
  }

  function rerenderIfPresent() {
    const current = document.getElementById(SHELF_ID);
    if (!current || !lastResult) return;
    current.replaceWith(buildSection(lastResult));
  }

  // --- make sure a video opened from the shelf starts playing -----------------
  //
  // Opening a video from the shelf should behave like clicking any native
  // thumbnail: it just plays. We flag the click, then on the watch page
  // keep nudging the player for a few seconds until it is actually playing.

  const AUTOPLAY_KEY = 'watch-later-shelf-autoplay';

  function markAutoplay() {
    try {
      sessionStorage.setItem(AUTOPLAY_KEY, String(Date.now()));
    } catch (e) {
      /* storage unavailable: nothing to do */
    }
  }

  let autoplayTimer = null;

  function maybeAutoplay() {
    if (autoplayTimer) {
      clearInterval(autoplayTimer);
      autoplayTimer = null;
    }
    if (location.pathname !== '/watch') return;

    let stamp = 0;
    try {
      stamp = parseInt(sessionStorage.getItem(AUTOPLAY_KEY) || '0', 10);
    } catch (e) {
      return;
    }
    if (!stamp || Date.now() - stamp > 20000) return;

    const startedAt = Date.now();
    autoplayTimer = setInterval(() => {
      if (Date.now() - startedAt > 10000) {
        clearInterval(autoplayTimer);
        autoplayTimer = null;
        try { sessionStorage.removeItem(AUTOPLAY_KEY); } catch (e) { /* ignore */ }
        return;
      }
      const video = document.querySelector('video.html5-main-video, #movie_player video');
      if (!video) return;
      if (!video.paused && video.currentTime > 0) {
        // Playing: done.
        clearInterval(autoplayTimer);
        autoplayTimer = null;
        try { sessionStorage.removeItem(AUTOPLAY_KEY); } catch (e) { /* ignore */ }
        return;
      }
      const p = video.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {
          // Blocked by the browser: press the player's own play button.
          const btn = document.querySelector('.ytp-play-button');
          if (btn && /play/i.test(btn.getAttribute('data-title-no-tooltip') || btn.getAttribute('aria-label') || '')) {
            btn.click();
          }
        });
      }
    }, 300);
  }

  // --- keep the shelf in step with the real Watch Later list -------------------
  //
  // Refreshes when (a) YouTube's own edit-playlist call touches Watch Later in
  // this browser (page-bridge.js fires an event), (b) you come back to the
  // tab, and (c) every so often while the home page is open, which also
  // catches changes made on another tab or device.

  let pendingRefresh = false;
  let lastRefreshAt = Date.now();
  const POLL_MS = 45000;

  function signature(result) {
    return (result.videos || []).map((v) => `${v.videoId}|${v.title}`).join('\n');
  }

  async function refreshShelf() {
    const current = document.getElementById(SHELF_ID);
    if (!isHomePage() || !settings.showWatchLater || !current) {
      // Nothing visible to update: just make sure the next render is fresh.
      lastResult = null;
      lastResultAt = 0;
      return;
    }
    if (requestInFlight) {
      pendingRefresh = true;
      return;
    }
    requestInFlight = true;
    let result;
    try {
      result = await requestWatchLaterVideos();
    } finally {
      requestInFlight = false;
    }
    lastRefreshAt = Date.now();

    if (result && !result.error && (!lastResult || signature(result) !== signature(lastResult))) {
      lastResult = result;
      lastResultAt = Date.now();
      if (settings.useDearrow) await fetchBranding(result.videos);
      const old = document.getElementById(SHELF_ID);
      if (old) {
        // Keep the scrolling row where it was.
        const oldRow = old.lastElementChild;
        const scrollLeft = oldRow ? oldRow.scrollLeft : 0;
        rerenderIfPresent();
        const fresh = document.getElementById(SHELF_ID);
        if (fresh && fresh.lastElementChild && scrollLeft) fresh.lastElementChild.scrollLeft = scrollLeft;
      }
    }

    if (pendingRefresh) {
      pendingRefresh = false;
      refreshShelf();
    }
  }

  // Real-time updates. Any change to Watch Later (from this tab, or from another
  // tab through storage) starts a short retry ladder: YouTube's server can lag a
  // moment behind an edit, so keep re-checking until the list actually differs.
  let lastChangeAt = 0;
  let ladderTimers = [];
  const LADDER = [700, 2000, 4500, 9000, 16000, 30000];

  function startLadder(base) {
    ladderTimers.forEach(clearTimeout);
    ladderTimers = [];
    let done = false;
    LADDER.forEach((ms) => {
      ladderTimers.push(setTimeout(async () => {
        if (done || !document.getElementById(SHELF_ID)) return;
        await refreshShelf();
        if (lastResult && signature(lastResult) !== base) {
          done = true;
          ladderTimers.forEach(clearTimeout);
        }
      }, ms));
    });
  }

  function onWatchLaterChanged(fromOtherTab) {
    lastChangeAt = Date.now();
    lastResultAt = 0; // any cached list is stale now
    if (!fromOtherTab) {
      try { chrome.storage.local.set({ wlChangedAt: Date.now() }); } catch (e) { /* ignore */ }
    }
    if (lastResult && document.getElementById(SHELF_ID)) startLadder(signature(lastResult));
    else lastResult = null; // not on the home page: the next render fetches fresh
  }
  window.addEventListener('watch-later-shelf-changed', () => onWatchLaterChanged(false));

  // Clicking any "Watch later" control (hover clock icon, the three-dot menu entry, the Save dialog) means
  // the list is about to change, even if the network request can't be seen. Refresh the shelf.
  const WL_WORDS = /watch later|saved to watch|removed from watch/i;
  const WL_CONTROLS = 'button, a, ytd-menu-service-item-renderer, yt-list-item-view-model, tp-yt-paper-item, ytd-playlist-add-to-option-renderer, yt-thumbnail-overlay-toggle-button-view-model, ytd-thumbnail-overlay-toggle-button-renderer, yt-button-shape, [role="menuitem"], [role="checkbox"]';
  document.addEventListener('click', (e) => {
    try {
      const t = e.target && e.target.closest ? e.target.closest(WL_CONTROLS) : null;
      if (!t || t.closest('#' + SHELF_ID)) return;
      const label = ((t.getAttribute('aria-label') || '') + ' ' + (t.getAttribute('title') || '') + ' ' + (t.textContent || '').slice(0, 120));
      if (!WL_WORDS.test(label)) return;
      // Give YouTube a moment to send its request first, then start the refresh ladder.
      setTimeout(() => onWatchLaterChanged(false), 600);
    } catch (err) { /* ignore */ }
  }, true);

  window.addEventListener('focus', () => {
    if (isHomePage() && Date.now() - lastRefreshAt > 10000) refreshShelf();
  });

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && Date.now() - lastRefreshAt > 20000) refreshShelf();
  });

  setInterval(() => {
    if (document.visibilityState === 'visible' && isHomePage() && Date.now() - lastRefreshAt >= POLL_MS) {
      refreshShelf();
    }
  }, 15000);

  // --- setup / teardown --------------------------------------------------------

  function cleanUp() {
    if (isHomePage()) {
      const existing = document.getElementById(SHELF_ID);
      if (existing && existing.dataset.nativeMeasured === '0' && lastResult && measureNative()) {
        rerenderIfPresent();
      }
      ensureShelf();
    } else {
      removeShelf();
    }
  }

  function teardown() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function setup() {
    teardown();
    if (!isHomePage()) return;

    cleanUp();

    observer = new MutationObserver(() => {
      if (!isHomePage()) {
        teardown();
        return;
      }
      cleanUp();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  async function loadSettingsAndInit() {
    try {
      const stored = await chrome.storage.local.get(DEFAULTS);
      settings = { ...DEFAULTS, ...stored };
    } catch (e) {
      settings = { ...DEFAULTS };
    }
    setup();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.wlChangedAt) onWatchLaterChanged(true);
    let changed = false;
    Object.keys(DEFAULTS).forEach((key) => {
      if (changes[key]) {
        settings[key] = changes[key].newValue;
        changed = true;
      }
    });
    if (changed) cleanUp();
    if (changes.useDearrow) {
      refreshBrandingAndRerender();
    } else if (changes.watchLaterTextColor || changes.layoutMode || changes.hideThumbnails || changes.cardsPerRow) {
      rerenderIfPresent();
    }
  });

  // Re-render when YouTube's theme flips (light/dark switch, other theme extensions).
  if (window.RT && RT.bus) {
    RT.bus.addEventListener('theme', () => { if (settings.watchLaterTextColor === 'auto') rerenderIfPresent(); });
    let lastAllThumbs = null;
    RT.bus.addEventListener('apply', () => {
      const now = !!(RT.state && RT.state.tokens.has('thumbsHideAll'));
      if (lastAllThumbs !== null && now !== lastAllThumbs) rerenderIfPresent();
      lastAllThumbs = now;
    });
  }

  document.addEventListener('yt-navigate-finish', () => {
    setup();
    maybeAutoplay();
  });
  window.addEventListener('load', loadSettingsAndInit);
  loadSettingsAndInit();
  maybeAutoplay();
  window.addEventListener('load', maybeAutoplay);
})();
