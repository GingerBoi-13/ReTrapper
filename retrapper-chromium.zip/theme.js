// Popup theme. "Auto" (no saved choice) follows the YouTube theme last seen
// by the extension, falling back to the system setting, and updates live.
// The Light/Dark buttons are an override; tap the active one to go back to auto.
(function () {
  var mq = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
  var seen = null;
  function saved() { try { var t = localStorage.getItem('retrapperPopupTheme'); return t === 'light' || t === 'dark' ? t : null; } catch (e) { return null; } }
  function effective() { return saved() || seen || (mq && mq.matches ? 'dark' : 'light'); }
  function apply() { document.documentElement.setAttribute('data-theme', effective()); if (window.__rtThemeChanged) window.__rtThemeChanged(); }
  window.__rtTheme = { saved: saved, effective: effective, apply: apply,
    set: function (t) { try { if (t) localStorage.setItem('retrapperPopupTheme', t); else localStorage.removeItem('retrapperPopupTheme'); } catch (e) {} apply(); } };
  apply();
  if (mq && mq.addEventListener) mq.addEventListener('change', apply);
  try {
    chrome.storage.local.get(['ytTheme'], function (r) { if (r && (r.ytTheme === 'dark' || r.ytTheme === 'light')) { seen = r.ytTheme; apply(); } });
    chrome.storage.onChanged.addListener(function (c) { if (c.ytTheme && c.ytTheme.newValue) { seen = c.ytTheme.newValue; apply(); } });
  } catch (e) {}
})();
