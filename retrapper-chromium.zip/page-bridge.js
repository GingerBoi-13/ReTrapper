// Runs in the page's own JavaScript world.
//
// 1) Receives shelf-click navigation requests from content.js as a JSON
//    string and hands them to YouTube as an in-page navigation (objects
//    passed from the extension's isolated world arrive empty).
// 2) Watches YouTube's own "edit playlist" calls. When the Watch Later
//    playlist is changed (a video added or removed, from any button or menu
//    in this browser), it fires a plain event so the shelf can refresh.
(function () {
  'use strict';

  window.addEventListener('watch-later-shelf-navigate', (e) => {
    try {
      const detail = JSON.parse(e.detail);
      const app = document.querySelector('ytd-app');
      if (!app) return;
      app.dispatchEvent(new CustomEvent('yt-navigate', { detail, bubbles: true, composed: true }));
    } catch (err) {
      /* content.js falls back to a normal navigation */
    }
  });

  // --- playlist edits requested by the shelf ---------------------------------
  //
  // Menu actions on shelf videos (remove, undo, remove all) are sent here as
  // JSON. They are posted to YouTube's own edit-playlist endpoint using the
  // page's existing signed-in session, exactly as YouTube's own buttons do.

  function getCookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  }

  async function sha1Hex(text) {
    const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async function authHeader() {
    const sid = getCookie('SAPISID') || getCookie('__Secure-3PAPISID');
    if (!sid) return null;
    const ts = Math.floor(Date.now() / 1000);
    return `SAPISIDHASH ${ts}_${await sha1Hex(`${ts} ${sid} ${location.origin}`)}`;
  }

  window.addEventListener('watch-later-shelf-edit', async (e) => {
    let req;
    try {
      req = JSON.parse(e.detail);
    } catch (err) {
      return;
    }
    const reply = (ok, error) =>
      window.dispatchEvent(
        new CustomEvent('watch-later-shelf-edit-result', {
          detail: JSON.stringify({ requestId: req.requestId, ok: !!ok, error: error || null })
        })
      );
    try {
      const cfg = window.ytcfg;
      const get = (k) => (cfg && typeof cfg.get === 'function' ? cfg.get(k) : undefined);
      const context = get('INNERTUBE_CONTEXT');
      if (!context) return reply(false, 'no-context');
      const auth = await authHeader();
      if (!auth) return reply(false, 'not-signed-in');

      const headers = {
        'Content-Type': 'application/json',
        Authorization: auth,
        'X-Goog-AuthUser': String(get('SESSION_INDEX') || 0),
        'X-Origin': location.origin,
        'X-Youtube-Client-Name': String(get('INNERTUBE_CONTEXT_CLIENT_NAME') || 1),
        'X-Youtube-Client-Version': String(get('INNERTUBE_CONTEXT_CLIENT_VERSION') || (context.client && context.client.clientVersion) || '')
      };
      const visitor = get('VISITOR_DATA');
      if (visitor) headers['X-Goog-Visitor-Id'] = visitor;
      const key = get('INNERTUBE_API_KEY');
      const url = '/youtubei/v1/browse/edit_playlist?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : '');

      const res = await window.fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({ context, playlistId: 'WL', actions: req.actions })
      });
      let json = null;
      try { json = await res.json(); } catch (err) { /* no body */ }
      const ok = res.ok && (!json || !json.status || json.status === 'STATUS_SUCCEEDED');
      reply(ok, ok ? null : `http-${res.status}`);
    } catch (err) {
      reply(false, String(err));
    }
  });

  const EDIT_RE = /\/youtubei\/v1\/browse\/edit_playlist/;

  function touchesWatchLater(bodyText) {
    // Unknown body: assume it might be Watch Later (an extra refresh is harmless).
    if (!bodyText) return true;
    try {
      const body = JSON.parse(bodyText);
      return !!body && body.playlistId === 'WL';
    } catch (e) {
      return /"playlistId"\s*:\s*"WL"/.test(String(bodyText));
    }
  }

  function notify() {
    window.dispatchEvent(new CustomEvent('watch-later-shelf-changed'));
  }

  // Reads the request body however YouTube passed it (string, Blob, bytes or
  // a Request). Must be called before the request is sent.
  async function readBody(input, init) {
    try {
      const b = init && init.body;
      if (typeof b === 'string') return b;
      if (b && typeof b.text === 'function') return await b.text();
      if (b && (b instanceof ArrayBuffer || ArrayBuffer.isView(b))) return new TextDecoder().decode(b);
      if (!b && input && typeof input.clone === 'function') return await input.clone().text();
    } catch (e) { /* unknown body */ }
    return '';
  }

  const originalFetch = window.fetch;
  window.fetch = function (input, init) {
    let bodyPromise = null;
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      if (EDIT_RE.test(url)) bodyPromise = readBody(input, init);
    } catch (e) { /* never break YouTube's own requests */ }
    const result = originalFetch.apply(this, arguments);
    if (bodyPromise) {
      Promise.all([result, bodyPromise]).then(([res, text]) => {
        if (res && res.ok && touchesWatchLater(text)) notify();
      }).catch(() => {});
    }
    return result;
  };

  // Same watch for edit calls made through XMLHttpRequest.
  const xOpen = XMLHttpRequest.prototype.open;
  const xSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    try { this.__wlUrl = String(url); } catch (e) { /* ignore */ }
    return xOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (this.__wlUrl && EDIT_RE.test(this.__wlUrl)) {
        const text = typeof body === 'string' ? body : '';
        this.addEventListener('load', () => {
          if (this.status >= 200 && this.status < 300 && touchesWatchLater(text)) notify();
        });
      }
    } catch (e) { /* ignore */ }
    return xSend.apply(this, arguments);
  };

  // Fallback signal: YouTube's own confirmation toast ("Saved to Watch later",
  // "Removed from Watch later"), in case a change goes through some other path.
  let toastTimer = 0;
  const toastWatcher = new MutationObserver((muts) => {
    for (const m of muts) {
      for (const n of m.addedNodes) {
        if (n.nodeType !== 1 || !/TOAST|NOTIFICATION-ACTION|SNACKBAR/.test(n.tagName || '')) continue;
        setTimeout(() => {
          const t = n.textContent || '';
          if (/watch later/i.test(t) && /(added|saved|removed)/i.test(t)) {
            clearTimeout(toastTimer);
            toastTimer = setTimeout(notify, 300);
          }
        }, 150);
      }
    }
  });
  let toastTries = 0;
  const toastFind = setInterval(() => {
    const pc = document.querySelector('ytd-popup-container');
    if (pc) { toastWatcher.observe(pc, { childList: true, subtree: true }); clearInterval(toastFind); }
    else if (++toastTries > 120) clearInterval(toastFind);
  }, 1000);

  // --- exact upload dates for ReTrapper ---------------------------------------
  // Looks a video's full upload timestamp up (the player response already
  // holds it for the video being watched; otherwise ask YouTube's player API).
  (function () {
    const queue = [];
    let busy = false;
    function pick(r) {
      const m = r && r.microformat && r.microformat.playerMicroformatRenderer;
      if (!m) return '';
      const live = m.liveBroadcastDetails || {};
      const c = [live.startTimestamp, m.uploadDate, m.publishDate].filter(Boolean);
      return c.find((x) => /T/.test(x)) || c[0] || '';
    }
    async function lookup(id) {
      try {
        const p = document.getElementById('movie_player');
        const r = p && typeof p.getPlayerResponse === 'function' ? p.getPlayerResponse() : null;
        if (r && r.videoDetails && r.videoDetails.videoId === id) { const d = pick(r); if (d) return d; }
      } catch (e) { /* fall through */ }
      try {
        const ir = window.ytInitialPlayerResponse;
        if (ir && ir.videoDetails && ir.videoDetails.videoId === id) { const d = pick(ir); if (d) return d; }
      } catch (e) { /* fall through */ }
      // 1) YouTube's player API
      try {
        const cfg = window.ytcfg && typeof window.ytcfg.get === 'function' ? window.ytcfg : null;
        const ctx = cfg && cfg.get('INNERTUBE_CONTEXT');
        if (ctx) {
          const key = cfg.get('INNERTUBE_API_KEY');
          const res = await fetch('/youtubei/v1/player?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ context: ctx, videoId: id, contentCheckOk: true, racyCheckOk: true })
          });
          if (res.ok) { const d = pick(await res.json()); if (d) return d; }
        }
      } catch (e) { /* fall through */ }
      // 2) the video's own page
      try {
        const res = await fetch('/watch?v=' + encodeURIComponent(id), { credentials: 'same-origin' });
        if (res.ok) {
          const html = await res.text();
          const all = [...html.matchAll(/"(?:uploadDate|publishDate|startTimestamp)":"([^"]+)"/g)].map((m) => m[1]);
          return all.find((x) => /T/.test(x)) || all[0] || '';
        }
      } catch (e) { /* give up */ }
      return '';
    }
    async function drain() {
      if (busy) return;
      busy = true;
      while (queue.length) {
        const id = queue.shift();
        let date = '';
        try { date = await Promise.race([lookup(id), new Promise((r) => setTimeout(() => r(''), 8000))]); } catch (e) { date = ''; }
        window.dispatchEvent(new CustomEvent('rt-date-res', { detail: JSON.stringify({ id, date }) }));
        await new Promise((r) => setTimeout(r, 150));
      }
      busy = false;
    }
    window.addEventListener('rt-date-req', (e) => {
      let req;
      try { req = JSON.parse(e.detail); } catch (err) { return; }
      if (req && /^[\w-]{11}$/.test(req.id) && !queue.includes(req.id)) { queue.push(req.id); drain(); }
    });
  })();

  // --- channel search support for ReTrapper ------------------------------------
  // Reads video lists (channel playlists, search results) from YouTube's own
  // API and returns them in a small, uniform shape.
  (function () {
    const txt = (x) => (!x ? '' : x.simpleText || x.content || (Array.isArray(x.runs) ? x.runs.map((r) => r.text).join('') : ''));
    const num = (s) => {
      const m = String(s || '').replace(/,/g, '').match(/([\d.]+)\s*([KMB])?/i);
      if (!m) return 0;
      return Math.round(parseFloat(m[1]) * ({ K: 1e3, M: 1e6, B: 1e9 }[(m[2] || '').toUpperCase()] || 1));
    };
    function fromRenderer(v) {
      const info = v.videoInfo ? txt(v.videoInfo).split(/\s*[•·]\s*/) : [];
      const owner = v.ownerText || v.longBylineText || v.shortBylineText;
      const run = owner && owner.runs && owner.runs[0];
      const browse = run && run.navigationEndpoint && run.navigationEndpoint.browseEndpoint;
      const snip = v.descriptionSnippet ? txt(v.descriptionSnippet)
        : (v.detailedMetadataSnippets && v.detailedMetadataSnippets[0] ? txt(v.detailedMetadataSnippets[0].snippetText) : '');
      const badges = JSON.stringify(v.badges || []) + JSON.stringify(v.thumbnailOverlays || []);
      return {
        id: v.videoId, title: txt(v.title), len: txt(v.lengthText) || (info.length > 2 ? '' : ''),
        views: txt(v.viewCountText) || info.find((x) => /view|watching/i.test(x)) || '',
        ago: txt(v.publishedTimeText) || info.find((x) => /ago|stream|premier/i.test(x)) || '',
        ch: run ? run.text : '', chId: (browse && browse.browseId) || '', snip,
        live: /"LIVE"|BADGE_STYLE_TYPE_LIVE_NOW/.test(badges), short: /\/shorts\//.test(JSON.stringify(v.navigationEndpoint || {}))
      };
    }
    function findDuration(o, d) {
      if (!o || typeof o !== 'object' || d > 14) return '';
      if (typeof o.text === 'string' && /^\d+(:\d{2}){1,2}$/.test(o.text.trim())) return o.text.trim();
      for (const k in o) { const r = findDuration(o[k], d + 1); if (r) return r; }
      return '';
    }
    function fromLockup(v) {
      const type = String(v.contentType || '');
      if (type && !/VIDEO|SHORT|STREAM/i.test(type)) return null;
      const m = v.metadata && v.metadata.lockupMetadataViewModel;
      if (!m || !v.contentId) return null;
      const rows = (((m.metadata || {}).contentMetadataViewModel || {}).metadataRows || []);
      const parts = [];
      rows.forEach((r) => (r.metadataParts || []).forEach((p) => { const t = txt(p.text); if (t) parts.push(t); }));
      return {
        id: v.contentId, title: txt(m.title), len: findDuration(v.contentImage, 0),
        views: parts.find((x) => /view|watching/i.test(x)) || '', ago: parts.find((x) => /ago|stream|premier/i.test(x)) || '',
        ch: '', chId: '', snip: '', live: /LIVE/i.test(JSON.stringify(v.contentImage || {}).slice(0, 4000)) && /watching/i.test(parts.join(' ')),
        short: /SHORT/i.test(type)
      };
    }
    function fromShort(v) {
      const id = v.videoId || (v.onTap && v.onTap.innertubeCommand && v.onTap.innertubeCommand.reelWatchEndpoint && v.onTap.innertubeCommand.reelWatchEndpoint.videoId) || '';
      if (!id) return null;
      const t = v.headline ? txt(v.headline) : (v.overlayMetadata && v.overlayMetadata.primaryText ? txt(v.overlayMetadata.primaryText) : '');
      const views = v.viewCountText ? txt(v.viewCountText) : (v.overlayMetadata && v.overlayMetadata.secondaryText ? txt(v.overlayMetadata.secondaryText) : '');
      return { id, title: t, len: '', views, ago: '', ch: '', chId: '', snip: '', live: false, short: true };
    }
    function collect(json) {
      const out = { items: [], cont: '' };
      (function walk(o, d) {
        if (!o || typeof o !== 'object' || d > 40) return;
        if (Array.isArray(o)) { o.forEach((x) => walk(x, d + 1)); return; }
        for (const k in o) {
          const v = o[k];
          if (k === 'videoRenderer' || k === 'playlistVideoRenderer' || k === 'gridVideoRenderer' || k === 'compactVideoRenderer') {
            if (v && v.videoId) out.items.push(fromRenderer(v));
          } else if (k === 'lockupViewModel') {
            const it = fromLockup(v); if (it) out.items.push(it);
          } else if (k === 'reelItemRenderer' || k === 'shortsLockupViewModel') {
            const it = fromShort(v); if (it) out.items.push(it);
          } else {
            if (k === 'continuationCommand' && v && v.token) out.cont = v.token;
            walk(v, d + 1);
          }
        }
      })(json, 0);
      const seen = new Set();
      out.items = out.items.filter((x) => x.id && !seen.has(x.id) && seen.add(x.id));
      out.items.forEach((x) => { x.viewsN = num(x.views); });
      return out;
    }

    window.addEventListener('rt-yt-req', async (e) => {
      let req;
      try { req = JSON.parse(e.detail); } catch (err) { return; }
      const reply = (o) => window.dispatchEvent(new CustomEvent('rt-yt-res', { detail: JSON.stringify(Object.assign({ id: req.id }, o)) }));
      try {
        if (req.kind === 'channel') {
          const b = document.querySelector('ytd-browse');
          const meta = b && b.data && b.data.metadata && b.data.metadata.channelMetadataRenderer;
          return reply({ channelId: (meta && meta.externalId) || '', name: (meta && meta.title) || '' });
        }
        const cfg = window.ytcfg && typeof window.ytcfg.get === 'function' ? window.ytcfg : null;
        const ctx = cfg && cfg.get('INNERTUBE_CONTEXT');
        if (!ctx) return reply({ error: 'no-context' });
        const key = cfg.get('INNERTUBE_API_KEY');
        const res = await fetch('/youtubei/v1/' + req.endpoint + '?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), {
          method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' },
          body: JSON.stringify(Object.assign({ context: ctx }, req.body))
        });
        if (!res.ok) return reply({ error: 'http ' + res.status });
        const out = collect(await res.json());
        reply({ items: out.items, cont: out.cont });
      } catch (err) { reply({ error: String(err).slice(0, 120) }); }
    });
  })();

  // --- player commands for ReTrapper (quality, volume, caption tracks) ---------
  window.addEventListener('rt-cmd', (e) => {
    let req;
    try { req = JSON.parse(e.detail); } catch (err) { return; }
    const reply = (ok, result) =>
      window.dispatchEvent(new CustomEvent('rt-cmd-result', { detail: JSON.stringify({ id: req.id, ok: !!ok, result: result === undefined ? null : result }) }));
    try {
      const p = document.getElementById('movie_player');
      if (!p) return reply(false, 'no-player');
      if (req.cmd === 'quality') {
        if (typeof p.setPlaybackQualityRange !== 'function') return reply(false, 'no-api');
        p.setPlaybackQualityRange(req.arg, req.arg);
        if (typeof p.setPlaybackQuality === 'function') p.setPlaybackQuality(req.arg);
        return reply(true, typeof p.getPlaybackQuality === 'function' ? p.getPlaybackQuality() : null);
      }
      if (req.cmd === 'getQuality') {
        return reply(true, typeof p.getPlaybackQuality === 'function' ? p.getPlaybackQuality() : null);
      }
      if (req.cmd === 'audioOriginal') {
        if (typeof p.getAvailableAudioTracks !== 'function' || typeof p.setAudioTrack !== 'function') return reply(false, 'no-api');
        const tracks = p.getAvailableAudioTracks() || [];
        const hit = tracks.find((t) => { try { return /original/i.test(JSON.stringify(t)); } catch (err) { return false; } });
        if (hit) { p.setAudioTrack(hit); return reply(true, 'set'); }
        return reply(true, 'none');
      }
      if (req.cmd === 'volume') {
        if (typeof p.setVolume !== 'function') return reply(false, 'no-api');
        p.setVolume(req.arg);
        return reply(true);
      }
      if (req.cmd === 'tracks') {
        const r = typeof p.getPlayerResponse === 'function' ? p.getPlayerResponse() : null;
        const t = r && r.captions && r.captions.playerCaptionsTracklistRenderer;
        const tracks = ((t && t.captionTracks) || []).map((x) => ({
          url: x.baseUrl, lang: x.languageCode, kind: x.kind || '',
          name: x.name && (x.name.simpleText || (x.name.runs && x.name.runs[0] && x.name.runs[0].text)) || ''
        }));
        const d = (r && r.videoDetails) || {};
        return reply(true, { tracks, title: d.title || '', id: d.videoId || '', length: +d.lengthSeconds || 0 });
      }
      reply(false, 'unknown-cmd');
    } catch (err) {
      reply(false, String(err));
    }
  });
})();
