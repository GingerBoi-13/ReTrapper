// Brings back the dislike count on watch pages using the community
// Return YouTube Dislike API (fetched by the background worker).
// The numbers are estimates: YouTube no longer publishes real dislike counts.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const cache = new Map(); // videoId -> {dislikes, likes} | null
  let pending = '';

  const fmt = (n) => {
    try { return new Intl.NumberFormat().format(n); }
    catch (e) { return String(n); }
  };
  const videoId = () => (location.pathname === '/watch' ? new URLSearchParams(location.search).get('v') || '' : '');
  const on = () => !!(RT.state && !RT.state.tokens.has('hideDislike'));
  const button = () =>
    document.querySelector('ytd-watch-flexy dislike-button-view-model button') ||
    document.querySelector('ytd-watch-flexy #segmented-dislike-button button');

  const likeBtn = () =>
    document.querySelector('ytd-watch-flexy like-button-view-model button') ||
    document.querySelector('ytd-watch-flexy #segmented-like-button button');

  // Exact like count: from the estimate service, else from the button's own label ("... along with 9,422 other people").
  function renderLikes(data) {
    const lb = likeBtn();
    document.querySelectorAll('.rt-like-count').forEach((e) => { if (!lb || !lb.contains(e)) e.remove(); });
    if (!lb) return;
    let span = lb.querySelector('.rt-like-count');
    const tokens = (RT.state && RT.state.tokens) || new Set();
    let n = null;
    const m = (lb.getAttribute('aria-label') || '').match(/along with ([\d,.\s]+) other/i);
    if (m) n = parseInt(m[1].replace(/\D/g, ''), 10) || 0;      // YouTube's own live figure
    else if (data && typeof data.likes === 'number') n = data.likes;
    if (n === null || tokens.has('hideLikes') || tokens.has('hideLike')) { if (span) span.remove(); lb.removeAttribute('data-rt-likes'); return; }
    if (!span) {
      span = document.createElement('span');
      span.className = 'rt-like-count yt-spec-button-shape-next__button-text-content';
      span.style.cssText = 'margin-left:6px;font:inherit';
      lb.appendChild(span);
    }
    lb.style.width = 'auto'; lb.style.minWidth = '0'; lb.style.overflow = 'visible';
    lb.setAttribute('data-rt-likes', '1');
    const text = fmt(n);
    if (span.textContent !== text) span.textContent = text;
  }

  function status(id, data) {
    const v = [likeBtn() ? 'likeBtn' : 'noLikeBtn', button() ? 'dislikeBtn' : 'noDislikeBtn', 'on:' + on(),
      'api:' + (!id ? 'noid' : cache.has(id) ? (data ? 'ok' : 'null') : 'pending'), 'dislikes:' + (data ? data.dislikes : '-'), 'likes:' + (data ? data.likes : '-')].join(' ');
    if (document.documentElement.getAttribute('data-rt-votes') !== v) document.documentElement.setAttribute('data-rt-votes', v);
  }

  function render() {
    const id0 = videoId();
    status(id0, id0 ? cache.get(id0) : null);
    renderLikes(id0 && on() ? cache.get(id0) : null);
    const btn = button();
    document.querySelectorAll('.rt-dislike-count').forEach((e) => { if (!btn || !btn.contains(e)) e.remove(); });
    if (!btn) return;
    let span = btn.querySelector('.rt-dislike-count');
    const id = videoId();
    const data = id && on() ? cache.get(id) : null;
    if (!data || typeof data.dislikes !== 'number') { if (span) span.remove(); return; }
    if (!span) {
      span = document.createElement('span');
      span.className = 'rt-dislike-count yt-spec-button-shape-next__button-text-content';
      span.style.cssText = 'margin-left:6px;font:inherit';
      btn.appendChild(span);
      btn.style.width = 'auto';
    }
    const text = fmt(data.dislikes);
    if (span.textContent !== text) span.textContent = text;
    span.title = 'Estimated dislikes (Return YouTube Dislike)';
  }

  async function load() {
    const id = videoId();
    if (!id || !on() || cache.has(id) || pending === id) { render(); return; }
    pending = id;
    let data = null;
    try { data = await chrome.runtime.sendMessage({ type: 'RT_DISLIKES', videoId: id }); } catch (e) { /* ignore */ }
    cache.set(id, data);
    if (pending === id) pending = '';
    render();
  }

  const tick = () => { load(); render(); };
  ['apply', 'navigate', 'dom'].forEach((ev) => RT.bus.addEventListener(ev, tick));
  document.addEventListener('yt-navigate-finish', () => setTimeout(tick, 400));
  setInterval(() => { if (videoId() && on()) render(); }, 2000); // the button is re-created by YouTube
})();
