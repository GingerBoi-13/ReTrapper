// Runs inside YouTube's live chat frame: switches "Top chat" to "Live chat".
(function () {
  'use strict';
  let tries = 0, done = false;
  const read = () => new Promise((res) => { try { chrome.storage.local.get('liveChatDefault', (r) => res(!!(r && r.liveChatDefault))); } catch (e) { res(false); } });
  const text = (e) => (e.textContent || '').trim();
  async function run() {
    if (done || ++tries > 25) return;
    if (!(await read())) return;
    const menu = document.querySelector('yt-live-chat-header-renderer yt-dropdown-menu, yt-live-chat-header-renderer #chat-view-selector-menu');
    const trigger = menu && (menu.querySelector('#trigger, tp-yt-paper-button, button') || menu);
    if (!trigger) return setTimeout(run, 800);
    const label = text(menu);
    if (/^live chat/i.test(label) && !/top chat/i.test(label)) { done = true; return; }
    trigger.click();
    setTimeout(() => {
      const item = [...document.querySelectorAll('tp-yt-paper-listbox a, tp-yt-paper-item, yt-dropdown-menu a')].find((e) => /^live chat( replay)?$/i.test(text(e)));
      if (item) { item.click(); done = true; } else { document.body.click(); setTimeout(run, 1200); }
    }, 250);
  }
  setTimeout(run, 1500);
})();
