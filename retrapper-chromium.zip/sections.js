// Popup sections (the dropdown list). Rows are item ids, {header:'text'}, or {hub:[[label, sectionId], ...]}.
(function () {
  'use strict';
  const RT = window.RT;
  const S = RT._h.section;

  S('home', 'Home page', ['gridColumns', 'hideHomeChips', 'hideAllSuggestions', 'homeFirstRowOnly', 'homeExtraRows', 'homeMaxRows', 'hideShortsHome',
    'hideTrendingRow', 'hideOtherRows', 'noInfiniteScroll', 'hideWatched', 'watchedMinPct', 'hideHomeAds', 'homeRedirect', 'homeRedirectUrl', 'hideExplore',
    'hideTrending', 'hideAllRecs', 'hidePersonalized', 'hideForYou']);
  S('shorts', 'Shorts', ['hideShortsAll', 'hideShortsHome', 'hideShortsSearch', 'hideShortsSubs', 'hideShortsRecs', 'hideShortsSidebar',
    'redirectShorts', 'shortsAsVideos', 'hideShortsSections', 'hideShortsSuggestions', 'hideShortsRelated']);
  S('video', 'Video page', ['hideWatchSidebar', 'hideRelated', 'hideEndscreenSuggestions', 'hideEndscreenInfo', 'hideLiveChat', 'hideComments',
    'hideCommentCount', 'hideRepliesCount', 'hideDescription', 'hideTitle', 'hideChannelInfo', 'hideOwnerInfo', 'hideMenuButtons', 'hideLike',
    'hideDislike', 'hideAiButtons', 'hideShare', 'hideSave', 'hideClip', 'hideDownload', 'hideOtherButtons', 'hideVideoMetadata', 'hideViews', 'hideLikes',
    'hideSubscribers', 'hidePubDate', 'hideTimeSince', 'hideAds', 'hideSidebarAds', 'hideVideoOverlays', 'hideVideoEndScreen', 'lowercaseTitles']);
  S('player', 'Player', ['fullWindowPlayer', 'fullSizePlayer', 'resizablePlayer', 'autoTheater', 'expandTheatre', 'autoFullscreen', 'minimalPlayer',
    'hidePlayerControls', 'playerControlsHide', 'vfBrightness', { header: 'Video filters' }, 'vfContrast', 'vfSaturate', 'vfSepia', 'grayscaleVideo',
    'ambientIntensity', 'disableAmbient', 'defaultQuality', 'defaultSpeed', 'disableAutoplay', 'intelligentLooping', 'loopMaxMinutes', 'loopVideos',
    'playlistNavigation', 'autoSkipPromos', 'hideVideoPromos', 'hidePlayerAds']);
  S('thumbnails', 'Thumbnails', ['thumbsHideAll', 'blurThumbs', 'blurAmount', 'grayThumbs', 'modifyThumbs', 'reduceThumbs',
    'thumbOpacity']);
  S('search', 'Search', ['hideShortsSearch', 'hideForYou', 'hideTrending', 'hidePersonalized', 'hidePeopleAlso', 'hidePromotedSites', 'hidePromotedVideos',
    'hideProducts', 'hideSearchAds', 'hideSearchRecs', 'hideSearchAutocomplete', 'hideSearchChips', 'searchHideWatched', 'searchLayout', 'inPageFilter', 'searchHide', 'searchThumbs']);
  S('subs', 'Subscriptions', ['hideShortsSubs', 'hideSubsSections', 'hideSubsRecSections', 'subsColumns', { header: 'Customize subscription feed' },
    'subsHideWatched', 'hideLiveStreams', 'hidePremieres', 'hideMembersOnly', 'subsKeywords', 'hideLatest', 'subsNavHide']);
  S('channels', 'Channel pages', ['channelSearch', 'channelSearchDeep', 'channelSearchFuzzy', 'channelSearchGrid', 'customChannelColumns', 'channelSearchColumns', 'hideChannelSections', 'hideChannelRecs', 'hideChannelHeaderInfo', 'hideChannelBanner', 'channelColumns',
    'channelDefaultTab', 'channelKeywords', 'hideChannelDistractions', 'channelNavHide']);
  S('sidebar', 'Left navigation / sidebar', ['hideSidebarAll', 'hideNavHome', 'hideShortsSidebar', 'hideNavSubs', 'hideNavLibrary', 'hideExplore', 'hideExploreButton',
    'hideMoreFromYT', 'hideLibrarySection', 'hideSubsSection', 'hideHelperButtons', 'hideGuideFooter', 'navSectionNames', 'navButtonNames', 'sidebarSelectors', 'sidebarAutoCollapse']);
  S('header', 'Top header', ['hideHeader', 'hideSearchBtn', 'hideSearchBar', 'hideLogo', 'disableLogoLink', 'hideBell', 'hideCreate', 'hideVoice',
    'hideHeaderControls', 'hideHeaderNav', 'headerAutoHide', 'headerSelectors']);
  S('recs', 'Recommendations', ['hideAllRecs', 'hideRelated', 'hideHomeChips', 'hideOtherRows', 'hidePersonalized', 'hideTrending', 'hideExplore', 'hideForYou',
    'hideSuggestedContent', 'recKeywords', 'recTopics', 'recBlockedChannels']);
  S('filters', 'Content filtering', ['filtersEnabled', 'blockVideos', 'blockChannels', 'filterChannelIds', 'filterChannelKeywords', 'blockKeywords',
    'filterVideoKeywords', 'blockTopics', 'muteTopics', 'filterRegex', 'blockCommentAuthors', 'commentKeywords', 'commentRegex', 'matchVideos', 'matchChannels',
    'matchComments', 'matchTopics', 'parentalFilter', 'parentalWords', 'minDurationMin', 'maxDurationMin', 'hideLiveStreams', 'hidePremieres', 'hideMembersOnly',
    'hideMixes', 'filterFeeds', 'filterRecsOn']);
  S('ads', 'Ads & promotions', ['hideVideoAds', 'hideBannerAds', 'hideSidebarAds', 'hidePromotedSites', 'hidePromotedVideos', 'hideProducts', 'hideAdSlots',
    'autoSkipPromos', 'removePromoUI']);
  S('comments', 'Comments', ['hideComments', 'hideCommentCount', 'hideReplies', 'hideRepliesCount', 'commentKeywords', 'blockCommentAuthors', 'commentRegex',
    'commentFilters', 'commentSort']);
  S('livechat', 'Live chat', ['hideLiveChat', 'removeLiveChatSection', 'removeLiveChatUI']);
  S('metrics', 'Metrics', ['showFullDates', 'hideLikes', 'hideViews', 'hideSubscribers', 'hidePubDate', 'hideTimeSince', 'hideCommentCount', 'hideRepliesCount', 'hideOtherMetrics', 'hideBadges']);
  S('interface', 'Interface / visual customization', ['minimalInterface', 'minimalLayout', 'cinemaMode', 'autoTheater', 'expandTheatre', 'customTheme', 'customAccent',
    'legacyLayout', 'legacyListViews', 'grayscaleUI', 'grayscaleAmount', 'blurCards', 'hideVisualElements', 'removeClutter', 'disableAmbient', 'pageMaxWidth',
    'customHideSelectors', 'customCss']);
  S('playback', 'Playback', ['disableAutoplay', 'defaultSpeed', 'defaultQuality', 'autoFullscreen', 'autoTheater', 'intelligentLooping', 'loopMaxMinutes', 'loopVideos',
    'playlistControls', 'playlistNavigation', 'autoSkipPromos', 'autoCaptions', 'defaultVolumeOn', 'defaultVolume']);
  S('automation', 'Automation', ['disableAutoplay', 'autoSkipPromos', 'autoFullscreen', 'autoTheater', 'homeRedirect', 'homeRedirectUrl', 'openingDelay', 'autoFocusMode',
    'focusSchedule', 'autoDistractionBlock', 'autoDistractAfterMin', 'customRules']);
  S('focus', 'Focus / productivity', ['zenMode', 'minimalistMode', 'wTimerFocus', 'sessionLimitMin', 'dailyLimitMin', 'timeBadge', 'timeReminderMin', 'accessIntent',
    'openingDelay', 'focusMode', 'distractionBlocking', 'wTimerDistract']);
  S('presets', 'Presets', ['wPresets', 'presetAuto', 'presetSchedule']);
  S('shortcuts', 'Keyboard shortcuts', ['hotkeysOn', 'hk_focus', 'hk_zen', 'hk_distraction', 'hk_nextPreset', 'hk_theater', 'customHotkeys']);
  S('transcript', 'Transcript', ['trEnhanced', 'trImproved', 'trNavigation', 'trTimestamps', 'trExpand', 'trAutoGenerated', 'aiLang']);
  // Settings pages (reached from the gear icon, not the section dropdown).
  S('password', 'Password', ['wPassword']);
  S('backup', 'Backup and restore', []);
  S('report', 'Bug report', []);
  S('access', 'Access controls', ['wTimerBlock', 'wTimerFocus', 'sessionLimitMin', 'openingDelay', 'accessIntent', 'focusRestrictions']);
  ['password', 'backup', 'access', 'report'].forEach((id) => { RT.SECTIONS.find((s) => s.id === id).settings = true; });
  S('notifications', 'Notifications', ['hideBell', 'removeNotifications', 'hideNotificationUI', 'hideNotificationRelated']);
  S('buttons', 'Buttons', ['hideMenuButtons', 'hideActionButtons', 'hideCreate', 'hideShare', 'hideLikeDislike', 'hideOtherPlayerButtons', 'customVisibleButtons']);
  S('pages', 'Page-specific controls', [{ hub: [['Home customization', 'home'], ['Search customization', 'search'], ['Subscription customization', 'subs'],
    ['Video-page customization', 'video'], ['Shorts customization', 'shorts'], ['Channel-page customization', 'channels'], ['Sidebar customization', 'sidebar'],
    ['Header customization', 'header'], ['Player customization', 'player'], ['Embedded-player customization', 'embed']] }]);
  S('embed', 'Embedded YouTube', ['embedPlayerSettings', 'embedVisualSettings', 'embedHideDistractions', 'embedCustom']);
  S('watchlater', 'Watch Later shelf', []);


  // Simple view: these show by default; everything else on the page sits under "More settings".
  RT.CORE = {
    home: ['gridColumns', 'hideHomeChips', 'hideAllSuggestions', 'hideShortsHome', 'noInfiniteScroll', 'hideWatched', 'watchedMinPct'],
    shorts: ['hideShortsAll', 'hideShortsHome', 'hideShortsSearch', 'hideShortsSubs', 'hideShortsRecs', 'redirectShorts'],
    video: ['hideWatchSidebar', 'hideRelated', 'hideEndscreenSuggestions', 'hideLiveChat', 'hideComments', 'hideDescription', 'hideAiButtons', 'hideAds'],
    player: ['autoTheater', 'disableAutoplay', 'defaultQuality', 'defaultSpeed', 'disableAmbient', 'minimalPlayer'],
    thumbnails: ['thumbsHideAll', 'blurThumbs', 'grayThumbs'],
    search: ['hideShortsSearch', 'hideSearchAds', 'hideSearchChips', 'hideSearchRecs', 'searchHideWatched', 'searchLayout'],
    subs: ['hideShortsSubs', 'subsHideWatched', 'hideLiveStreams', 'hidePremieres', 'subsColumns'],
    channels: ['channelSearch', 'channelSearchGrid', 'customChannelColumns', 'channelSearchColumns', 'hideChannelSections', 'hideChannelRecs', 'channelDefaultTab'],
    sidebar: ['hideSidebarAll', 'hideNavHome', 'hideShortsSidebar', 'hideNavSubs', 'hideExplore', 'hideMoreFromYT'],
    header: ['hideSearchBar', 'hideLogo', 'hideBell', 'hideCreate', 'hideVoice'],
    recs: ['hideAllRecs', 'hideRelated', 'hideHomeChips', 'hideTrending'],
    filters: ['filtersEnabled', 'blockChannels', 'blockKeywords', 'hideLiveStreams'],
    ads: ['hideVideoAds', 'hideBannerAds', 'hideSidebarAds', 'hideAdSlots'],
    comments: ['hideComments', 'commentSort', 'hideCommentCount'],
    metrics: ['showFullDates', 'hideLikes', 'hideViews', 'hideSubscribers'],
    interface: ['minimalInterface', 'cinemaMode', 'customTheme'],
    playback: ['disableAutoplay', 'defaultSpeed', 'defaultQuality', 'autoTheater'],
    automation: ['disableAutoplay', 'autoSkipPromos', 'homeRedirect'],
    focus: ['zenMode', 'minimalistMode', 'timeBadge', 'sessionLimitMin', 'dailyLimitMin']
  };

  RT.sectionById = (id) => RT.SECTIONS.find((s) => s.id === id);
})();
