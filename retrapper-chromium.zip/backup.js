(function () {
  const $ = (id) => document.getElementById(id);
  const PREFIX = 'RT1:';
  const sys = () => new Set(Object.keys(RT.SYSTEM_DEFAULTS));
  const keys = () => RT.featureKeys().filter((k) => !sys().has(k));
  const enc = (o) => PREFIX + btoa(unescape(encodeURIComponent(JSON.stringify(o))));
  const dec = (s) => JSON.parse(decodeURIComponent(escape(atob(s.trim().replace(/\s+/g, '').slice(PREFIX.length)))));
  const msg = (t, bad) => { $('bkMsg').textContent = t; $('bkMsg').style.color = bad ? '#cc0000' : ''; };
  function refresh() {
    msg('');
    chrome.storage.local.get(null, (st) => {
      const d = RT.defaults(), o = {};
      keys().forEach((k) => { o[k] = st[k] !== undefined ? st[k] : d[k]; });
      $('bkOut').value = enc(o);
    });
  }
  window.RTBackup = { refresh };
  $('bkCopy').onclick = () => {
    $('bkOut').select();
    (navigator.clipboard ? navigator.clipboard.writeText($('bkOut').value) : Promise.reject()).catch(() => document.execCommand('copy'));
    $('bkCopy').textContent = 'Copied';
    setTimeout(() => { $('bkCopy').textContent = 'Copy code'; }, 1200);
  };
  $('bkApply').onclick = () => {
    const raw = $('bkIn').value.trim();
    if (raw.indexOf(PREFIX) !== 0) return msg('That is not a ReTrapper backup code.', true);
    let obj;
    try { obj = dec(raw); } catch (e) { return msg('The code is damaged or incomplete.', true); }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return msg('The code is damaged or incomplete.', true);
    const d = RT.defaults(), out = {};
    keys().forEach((k) => {
      if (!(k in obj)) return;
      const v = obj[k], dv = d[k];
      if (Array.isArray(dv) ? Array.isArray(v) : typeof v === typeof dv) out[k] = v;
    });
    const n = Object.keys(out).length;
    if (!n) return msg('No settings found in that code.', true);
    chrome.storage.local.set(Object.assign(out, { activePreset: '' }), () => {
      msg('Applied ' + n + ' settings.');
      setTimeout(() => location.reload(), 600);
    });
  };
})();
