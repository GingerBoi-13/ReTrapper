// Bug report page (reached from the gear). Same collector as the ReTrapper Bug Report companion.
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const msg = (t, err) => { $('brMsg').textContent = t; $('brMsg').className = err ? 'err' : ''; };
  let tab = null, lastReport = '';
  const KEY = 'rtBugReportOptions', EMAIL_KEY = 'rtBugReportEmail', DEV_EMAIL = 'retrapper.skyward225@passmail.net';
  const BOXES = { brMask: 'mask', brMarkup: 'markup', brLookups: 'lookups' };
  const ids = Object.keys(BOXES);
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    ids.forEach((id) => { if (typeof saved[BOXES[id]] === 'boolean') $(id).checked = saved[BOXES[id]]; });
    $('brEmail').value = localStorage.getItem(EMAIL_KEY) || '';
  } catch (e) { /* ignore */ }
  const showSend = (on) => { $('brSend').hidden = !on; $('brSendNote').hidden = !on; };
  ids.forEach((id) => $(id).addEventListener('change', () => {
    showSend(false);
    try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(ids.map((b) => [BOXES[b], $(b).checked])))); } catch (e) { /* ignore */ }
  }));
  $('brNote').addEventListener('input', () => showSend(false));
  $('brEmail').addEventListener('input', () => { try { localStorage.setItem(EMAIL_KEY, $('brEmail').value.trim()); } catch (e) { /* ignore */ } });

  function refresh() {
    msg(''); $('brOut').style.display = 'none';
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      tab = tabs && tabs[0];
      const ok = tab && /^https:\/\/www\.youtube\.com\//.test(tab.url || '');
      ['brCopy', 'brSave', 'brView'].forEach((id) => { $(id).disabled = !ok; });
      $('brWhere').textContent = ok ? 'Describe the problem, then copy or save the report and send it to the developer.'
        : 'This only works on a YouTube page. Open the page with the problem, then open this page again.';
    });
  }
  window.RTReport = { refresh };

  async function generate() {
    if (!tab) throw new Error('No YouTube tab');
    const opts = { note: $('brNote').value.trim(), mask: $('brMask').checked, markup: $('brMarkup').checked, lookups: $('brLookups').checked };
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['report.js'] });
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', args: [opts], func: (o) => window.__rtBugReportBuild(o) });
    if (!res || typeof res.result !== 'string') throw new Error('No report returned');
    return res.result;
  }
  async function run(fn) {
    msg('Collecting...');
    try { await fn(await generate()); } catch (e) { msg('Failed: ' + (e && e.message || e), true); }
  }
  $('brCopy').onclick = () => run(async (t) => {
    lastReport = t;
    try { await navigator.clipboard.writeText(t); msg('Copied to clipboard. Press Send To Developer, or paste it wherever you like.'); }
    catch (e) { const o = $('brOut'); o.style.display = 'block'; o.value = t; o.select(); msg('Select all in the box below and copy it, then press Send To Developer.'); }
    showSend(true);
  });
  $('brSave').onclick = () => run((t) => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([t], { type: 'application/json' })); a.download = 'retrapper-bug-report.json';
    document.body.appendChild(a); a.click(); a.remove(); msg('Saved retrapper-bug-report.json');
  });
  $('brView').onclick = () => run((t) => { const o = $('brOut'); o.style.display = 'block'; o.value = t; msg(''); });
  $('brSend').onclick = async () => {
    const email = $('brEmail').value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { msg('Add your email above so the developer can reply.', true); $('brEmail').focus(); return; }
    try { await navigator.clipboard.writeText(lastReport); } catch (e) { /* the box below still holds the report */ }
    const note = $('brNote').value.trim().slice(0, 700);
    const body = 'Reply to: ' + email + '\n\n' + (note ? 'What happened:\n' + note + '\n\n' : '') +
      'Paste the report below this line (it is already copied: press Ctrl+V, or Cmd+V on a Mac):\n\n';
    const a = document.createElement('a');
    a.href = 'mailto:' + DEV_EMAIL + '?subject=' + encodeURIComponent('ReTrapper bug report') + '&body=' + encodeURIComponent(body);
    document.body.appendChild(a); a.click(); a.remove();
    msg('Your mail app should open. Paste the report into the message and press Send.');
  };
})();
